$(document).ready(function() {
    const token = "IGQVJYWHZAUSWY0SlVCTUFwM3RlNkNSazdYWDRrNl9WdE5UVzBJS2w3Q2d5RVhQM2VIU1ZAkbFBnekUxRExHUDhISzF3MFdaYnJMdnl5bXlHeEtJSG0yNjF2RURhWlZAfMlJQQTY2aXVGejgyQWxLWmthWQZDZD";
    const url = "https://graph.instagram.com/me/media?access_token=" + token + "&fields=media_url,media_type,caption,permalink";

    $.get(url).then(function(response) {
        let dadosJson = response.data;
        let conteudo = '<div class="row" style="padding-left: 5px;">';

        for (let i = 0; i < 6; i++) {
            let feed = dadosJson[i];
            let titulo = feed.caption !== null ? feed.caption : '';
            let tipo = feed.media_type;
            if (tipo === "VIDEO") {
                conteudo += '<div class="col-sm-6 col-md-4 col-xxl-4 col-xl-4 col-lg-4"><video style="width: 100%; height: 90%;" controls><source src="' + feed.media_url + '" type="video/mp4"></video></div>';
            } else if (tipo === "IMAGE") {
                conteudo += '<div class="col-sm-6 col-md-4 col-xxl-4 col-xl-4 col-lg-4"><img style="width: 100%; height: 90%;" title="' + titulo + '" alt="' + titulo + '" src="' + feed.media_url + '" onclick="window.open(\'' + feed.permalink + '\');"></div>';
            }
        }
        conteudo += "</div>";
        $('#insta').html(conteudo);
    })

    if ($("#telefone").length != 0) {
        $("#telefone").mask("(99) 99999-9999");
    }
    if ($(".order").length != 0) {
        $(".order").mask("9999");
    }
    if ($("#cpf").length != 0) {
        $("#cpf").mask("999.999.999-99");
    }
    if ($("#cep").length != 0) {
        $("#cep").mask("99999-999");
    }
    if ($(".time").length != 0) {
        $(".time").mask("99:99");
    }
    if ($("#data").length != 0) {
        $("#data").mask("99/99/9999");
    }
    if ($('#email').length != 0) {
        $('#email').mask("A", {
            translation: {
                "A": { pattern: /[\w@\-.+]/, recursive: true }
            }
        })
    };

    $('#map').addClass('scrolloff'); // set the mouse events to none when doc is ready

    $('#ingresso').addClass('anime_ingresso'); //animacao ingressos

    $('#overlay').on("mouseup", function() { // lock it when mouse up
        $('#map').addClass('scrolloff');
        //somehow the mouseup event doesn't get call...
    });
    $('#overlay').on("mousedown", function() { // when mouse down, set the mouse events free
        $('#map').removeClass('scrolloff');
    });

    $("#map").mouseleave(function() { // becuase the mouse up doesn't work... 
        $('#map').addClass('scrolloff'); // set the pointer events to none when mouse leaves the map area
        // or you can do it on some other event
    });
    $(document).on("click", ".js-menu_toggle.closed", function(a) {
        a.preventDefault();
        $(".list_load, .list_item").stop();
        $(".side_menu").removeClass("fecha_menu");
        $(this).removeClass("closed").addClass("opened");
        $(".side_menu").css({ left: "-40px" });
        a = $(".list_item").length;
        $(".list_load").slideDown(.6 * a * 100);
        $(".list_item").each(function(a) {
            var e = $(this);
            timeOut = 100 * a, setTimeout(function() { e.css({ opacity: "1", "margin-left": "0" }) }, 150 * a)
        })
    });
    $(document).on("click", ".js-menu_toggle.opened", function(a) {
        a.preventDefault();
        $(".list_load, .list_item").stop();
        $(this).removeClass("opened").addClass("closed");
        $(".side_menu").removeAttr("style");
        $(".side_menu").addClass("fecha_menu");
        $(".list_item").length;
        $(".list_item").css({ opacity: "0", "margin-left": "-20px" });
        $(".list_load").slideUp(300)
    })
});

function showatracoes(a) {
    switch (a) {
        case "prive":
            $("#carouselExampleIndicatorsnautico").addClass("escondeatracao");
            $("#carouselExampleIndicatorsnautico").removeClass("mostraatracao");
            $("#carouselExampleIndicatorswaterpark").addClass("escondeatracao");
            $("#carouselExampleIndicatorswaterpark").removeClass("mostraatracao");
            $("#carouselExampleIndicatorsprive").removeClass("escondeatracao");
            $("#carouselExampleIndicatorsprive").addClass("mostraatracao");
            $("#logo-prive").removeAttr("style");
            $("#logo-prive").attr("style", "opacity: 1;");
            $("#hr-prive").removeAttr("style");
            $("#hr-prive").attr("style", "background: #f68c16; opacity: 1; color: #f68c16");
            $("#hr-waterpark").removeClass("animacao");
            $("#hr-nautico").removeClass("animacao");
            $("#hr-prive").removeClass("animacao");
            $("#hr-prive").addClass("animacao");
            $("#logo-waterpark").removeAttr("style");
            $("#logo-waterpark").attr("style", "opacity: 0.6;");
            $("#hr-waterpark").removeAttr("style");
            $("#hr-waterpark").attr("style", "opacity: 0;");
            $("#logo-nautico").removeAttr("style");
            $("#logo-nautico").attr("style", "opacity: 0.6;");
            $("#hr-nautico").removeAttr("style");
            $("#hr-nautico").attr("style", "opacity: 0;");
            $("#chevron-prive").removeAttr("style");
            $("#chevron-waterpark").removeAttr("style");
            $("#chevron-nautico").removeAttr("style");
            $("#chevron-prive").attr("style", "display: none");
            break;
        case "waterpark":
            $("#carouselExampleIndicatorsnautico").addClass("escondeatracao");
            $("#carouselExampleIndicatorsnautico").removeClass("mostraatracao");
            $("#carouselExampleIndicatorsprive").addClass("escondeatracao");
            $("#carouselExampleIndicatorsprive").removeClass("mostraatracao");
            $("#carouselExampleIndicatorswaterpark").removeClass("escondeatracao");
            $("#carouselExampleIndicatorswaterpark").addClass("mostraatracao");
            $("#logo-prive").removeAttr("style");
            $("#logo-prive").attr("style", "opacity: 0.6;");
            $("#hr-prive").removeAttr("style");
            $("#hr-prive").attr("style", "opacity: 0;");
            $("#logo-waterpark").removeAttr("style");
            $("#logo-waterpark").attr("style", "opacity: 1;");
            $("#hr-waterpark").removeAttr("style");
            $("#hr-waterpark").attr("style", "background: #f68c16; opacity: 1; color: #f68c16");
            $("#hr-prive").removeClass("animacao");
            $("#hr-nautico").removeClass("animacao");
            $("#hr-waterpark").removeClass("animacao");
            $("#hr-waterpark").addClass("animacao");
            $("#logo-nautico").removeAttr("style");
            $("#logo-nautico").attr("style", "opacity: 0.6;");
            $("#hr-nautico").removeAttr("style");
            $("#hr-nautico").attr("style", "opacity: 0;");
            $("#chevron-prive").removeAttr("style");
            $("#chevron-waterpark").removeAttr("style");
            $("#chevron-nautico").removeAttr("style");
            $("#chevron-waterpark").attr("style", "display: none");
            break;
        case "nautico":
            $("#carouselExampleIndicatorsprive").addClass("escondeatracao");
            $("#carouselExampleIndicatorsprive").removeClass("mostraatracao");
            $("#carouselExampleIndicatorswaterpark").addClass("escondeatracao");
            $("#carouselExampleIndicatorswaterpark").removeClass("mostraatracao");
            $("#carouselExampleIndicatorsnautico").removeClass("escondeatracao");
            $("#carouselExampleIndicatorsnautico").addClass("mostraatracao");
            $("#logo-prive").removeAttr("style");
            $("#logo-prive").attr("style", "opacity: 0.6;");
            $("#hr-prive").removeAttr("style");
            $("#hr-prive").attr("style", "opacity: 0;");
            $("#logo-waterpark").removeAttr("style");
            $("#logo-waterpark").attr("style", "opacity: 0.6;");
            $("#hr-waterpark").removeAttr("style");
            $("#hr-waterpark").attr("style", "opacity: 0;");
            $("#logo-nautico").removeAttr("style");
            $("#logo-nautico").attr("style", "opacity: 1;");
            $("#hr-nautico").removeAttr("style");
            $("#hr-nautico").attr("style", "background: #f68c16; opacity: 1; color: #f68c16");
            $("#hr-prive").removeClass("animacao");
            $("#hr-waterpark").removeClass("animacao");
            $("#hr-nautico").removeClass("animacao");
            $("#hr-nautico").addClass("animacao");
            $("#chevron-prive").removeAttr("style");
            $("#chevron-waterpark").removeAttr("style");
            $("#chevron-nautico").removeAttr("style");
            $("#chevron-nautico").attr("style", "display: none");
    }
}

function open_answer(num) {
    $("#link_" + num).removeAttr('href');
    $("#link_" + num).attr('href', "#question" + num);
    var element = document.getElementById("seta_" + num);
    element.classList.toggle("animacao_seta");
    $("#link_" + num).removeAttr('onclick');
    $("#link_" + num).attr('onclick', "fechar_answer(" + num + ")");
}

function fechar_answer(num) {
    var element = document.getElementById("seta_" + num);
    element.classList.toggle("animacao_seta");
    $("#link_" + num).removeAttr('href');
    $("#link_" + num).attr('href', "#");
    $("#link_" + num).removeAttr('onclick');
    $("#link_" + num).attr('onclick', "open_answer(" + num + ")");
}

function open_questions(tipo) {
    if (tipo == 'gerais') {
        $('#button_internet').removeAttr('style');
        $('#button_gerais').attr('style', 'opacity: 1; text-decoration: underline;');
        $('#faq_internet').css('animation', '2s forwards faq_internet_close');
        $('#faq_gerais').css('animation', '2s forwards faq_gerais_open');
    }
    if (tipo == 'internet') {
        $('#button_gerais').removeAttr('style');
        $('#button_internet').attr('style', 'opacity: 1; text-decoration: underline;');
        $('#faq_internet').css('animation', '2s forwards faq_internet_open');
        $('#faq_gerais').css('animation', '2s forwards faq_gerais_close');
    }
}

var purecookieTitle = "Cookies!",
    purecookieDesc = "Ao usar este site, você automaticamente aceita que usemos cookies.",
    purecookieLink = '<a href="https://www.cssscript.com/privacy-policy/" target="_blank">Política de privacidade</a>',
    purecookieButton = "Aceitar";

function pureFadeIn(e, o) {
    var i = document.getElementById(e);
    i.style.opacity = 0, i.style.display = o || "block",
        function e() {
            var o = parseFloat(i.style.opacity);
            (o += .02) > 1 || (i.style.opacity = o, requestAnimationFrame(e))
        }()
}

function pureFadeOut(e) {
    var o = document.getElementById(e);
    o.style.opacity = 1,
        function e() {
            (o.style.opacity -= .02) < 0 ? o.style.display = "none" : requestAnimationFrame(e)
        }()
}

function setCookie(e, o, i) {
    var t = "";
    if (i) {
        var n = new Date;
        n.setTime(n.getTime() + 24 * i * 60 * 60 * 1e3), t = "; expires=" + n.toUTCString()
    }
    document.cookie = e + "=" + (o || "") + t + "; path=/"
}

function getCookie(e) {
    for (var o = e + "=", i = document.cookie.split(";"), t = 0; t < i.length; t++) {
        for (var n = i[t];
            " " == n.charAt(0);) n = n.substring(1, n.length);
        if (0 == n.indexOf(o)) return n.substring(o.length, n.length)
    }
    return null
}

function eraseCookie(e) { document.cookie = e + "=; Max-Age=-99999999;" }

function cookieConsent() { getCookie("purecookieDismiss") || (document.body.innerHTML += '<div class="cookieConsentContainer" id="cookieConsentContainer"><div class="cookieTitle"><a>' + purecookieTitle + '</a></div><div class="cookieDesc"><p>' + purecookieDesc + " " + purecookieLink + '</p></div><div class="cookieButton"><a onClick="purecookieDismiss();">' + purecookieButton + "</a></div></div>", pureFadeIn("cookieConsentContainer")) }

function purecookieDismiss() { setCookie("purecookieDismiss", "1", 7), pureFadeOut("cookieConsentContainer") }
window.onload = function() { cookieConsent() };

function mudar_valor() {
    var valor = document.getElementById('img').value;
    var exp = valor.split("\\");
    var valor = exp[exp.length - 1];
    $('#value_file').empty();
    $('#value_file').html(valor);
}

function disp() {
    document.cookie = "largeur=" + screen.width + "; expires=100";
    window.location.href = "index.php";
}


function remove_cookie() {
    var secont = new Date(new Date().getTime() - 1);
    document.cookie = "largeur=" + screen.width + "; expires=" + secont;
}

// Debounce do Lodash
debounce = function(func, wait, immediate) {
    var timeout;
    return function() {
        var context = this,
            args = arguments;
        var later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};

(function() {

    function animeScroll() {
        var document_top = $(document).scrollTop();
        var n_b = $(window).height() * 3 / 4;
        var position_0 = $('#newsletter').offset().top;
        if (document_top > position_0 - n_b) {
            $('#newsletter').addClass('anime_newsletter');
        }
    }

    $(document).scroll(debounce(function() {
        animeScroll();
    }, 200));
})();

function bot() {
    setTimeout(function() {
        if ($("#code7-boteria-bot-widget-image-faq").length) {
            var num = Math.floor(Math.random() * 7 + 1);
            $("#code7-boteria-bot-widget-image-faq").removeAttr("src");
            $("#code7-boteria-bot-widget-image-faq").attr("src", "assets/img/personagem" + num + ".svg");
            $("#code7-boteria-wapper-popup-message").empty();
            $("#code7-boteria-wapper-popup-message").css("display", "none");
        } else {
            bot();
        }
    }, 100);
}
bot();