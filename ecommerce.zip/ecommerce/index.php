<?php
require_once "assets/bib/conexao.php";

if (isset($_COOKIE["id"])) {
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
	<!-- Primary Meta Tags -->
	<title>Privé Diversão | Parques em Caldas Novas | Site Oficial</title>
	<meta name="title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
	<meta name="description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">

	<!-- Open Graph / Facebook -->
	<meta property="og:type" content="website">
	<meta property="og:url" content="https://metatags.io/">
	<meta property="og:title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
	<meta property="og:description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
	<meta property="og:image" content="https://metatags.io/assets/meta-tags-16a33a6a8531e519cc0936fbba0ad904e52d35f34a46c97a2c9f6f7dd7d336f2.png">

	<!-- Twitter -->
	<meta property="twitter:card" content="summary_large_image">
	<meta property="twitter:url" content="https://metatags.io/">
	<meta property="twitter:title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
	<meta property="twitter:description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
	<meta property="twitter:image" content="https://metatags.io/assets/meta-tags-16a33a6a8531e519cc0936fbba0ad904e52d35f34a46c97a2c9f6f7dd7d336f2.png">

	<!--- basic page needs
   ================================================== -->
	<meta charset="utf-8">
	<meta name="description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
	<meta name="author" content="SAULO COELHO DA COSTA JUNIOR +55 (64) 99300-7836">
	<meta name="keywords" content="parques, aquático, diversão, Caldas Novas, parque aquático, parque de diversão, water park, nautico, privé, clube, resort, prive">
	<meta name="robots" content="index, follow">
	<meta name="canonical" content="https://privediversao.com.br">
	<meta name="sitemap" type="application/xml" href="./sitemap.xml">

	<!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- favicons
	================================================== -->
	<link rel="shortcut icon" href="assets/img/favicon.webp">

	<!-- CSS
   ================================================== -->
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/style.css">

	<!-- script
   ================================================== -->
	<script src="assets/js/jquery.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-5D93CSS');
	</script>

	<script type="text/javascript">
		var analyticsFileTypes = [''];
		var analyticsSnippet = 'enabled';
		var analyticsEventTracking = 'enabled';
	</script>
	<script type="text/javascript">
		var _gaq = _gaq || [];

		_gaq.push(['_setAccount', 'UA-114439357-1']);
		_gaq.push(['_addDevId', 'i9k95']); // Google Analyticator App ID with Google
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script');
			ga.type = 'text/javascript';
			ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0];
			s.parentNode.insertBefore(ga, s);
		})();
	</script>

	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11071276188"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'AW-11071276188');
	</script>

	<script>
		gtag('event', 'page_view', {
			'send_to': 'AW-11071276188',
			'value': 'replace with value',
			'items': [{
				'id': 'replace with value',
				'start_date': 'replace with value',
				'end_date': 'replace with value',
				'google_business_vertical': 'hotel_rental'
			}, {
				'origin': 'replace with value',
				'destination': 'replace with value',
				'start_date': 'replace with value',
				'end_date': 'replace with value',
				'google_business_vertical': 'travel'
			}, {
				'id': 'replace with value',
				'location_id': 'replace with value',
				'google_business_vertical': 'custom'
			}]
		});
	</script>

	<!-- WEB CHAT -->
	<link rel="stylesheet" href="https://app.boteria.com.br/cdn/webchat/webchat.v2.css" />
	<script src="https://app.boteria.com.br/cdn/libs/showdown.min.js"></script>
	<script src="https://app.boteria.com.br/cdn/libs/axios.js"></script>
	<script src="https://app.boteria.com.br/cdn/libs/socket.io.js"></script>
	<script src="https://app.boteria.com.br/cdn/webchat/webchat.js"></script>
</head>

<?php
if (!isset($_COOKIE['largeur']) || $_COOKIE['largeur'] == '' || $_COOKIE['largeur'] == 'deleted') {
	echo "<body onload='disp()'>";
} else {
	// Código para exibir em caso de detecção da resolução de exibição
	if ($_COOKIE['largeur'] > 700) {
		$slide = 'slide_home_pc';
	} else {
		$slide = 'slide_home_mobile';
	}

	$key = "largeur";
	$path = '';
	$domain = '';
	$secure = false;
	if (isset($_COOKIE['largeur'])) {
		unset($_COOKIE[$key]);
	}
	echo "<body onload='remove_cookie()'>";
}
?>
<!-- Menu lateral -->
<div class="side_menu">
	<div class="burger_box">
		<div class="menu-icon-container">
			<a href="#" class="menu-icon js-menu_toggle closed" title="Ícone para abrir o menu">
				<span class="menu-icon_box">
					<span class="menu-icon_line menu-icon_line--1" style="height: 2px;"></span>
					<span class="menu-icon_line menu-icon_line--2"></span>
					<span class="menu-icon_line menu-icon_line--3"></span>
				</span>
			</a>
		</div>
		<a href="https://www.facebook.com/privediversao" title="Logo facebook">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" alt="Logo facebook">
				<path d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z" />
			</svg>
		</a>
		<a href="https://www.instagram.com/privediversao/" title="Logo instagram">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" alt="Logo instagram">
				<path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z" />
			</svg>
		</a>
		<a href="https://www.youtube.com/user/rededehoteisprive" title="Logo youtube">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" alt="Logo youtube">
				<path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z" />
			</svg>
		</a>
		<a href="https://www.tripadvisor.com.br/Search?geo=1012170&pid=3826&typeaheadRedirect=true&redirect=&startTime=1482514871259&uiOrigin=MASTHEAD&q=prive%20nautico%20water%20park&returnTo=http%253A__2F____2F__www__2E__tripadvisor__2E__com__2E__br__2F__&searchSessionId=DD87D6CD0E1E10320CA24123E1055CA01482514861433ssid#&ssrc=A&dist=5km&o=0&sid=6DC9E017DB034A749E75E5B7DBC1EEBC1668687013976&blockRedirect=true" title="Logo TripAdvisor">
			<img alt="Logo Trip Advisor" loading="lazy" src="assets/img/tripadvisor-logo.webp">
		</a>
		<a href="https://br.linkedin.com/company/grupoprive" title="Logo linkedin">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" alt="Logo linkedin">
				<path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z" />
			</svg>
		</a>
	</div>
	<div class="px-5">
		<img alt="Logo Privediversão" loading="lazy" class="list_item" src="assets/img/logo.webp" style="max-width: 40%; margin: 0 auto;">
		<hr style="color: #f68c16; background-color: #f68c16; height: 3px;">
		<ul class="list_load">
			<li class="list_item"><a href="#" onclick="mudar_img_chat()" title="Ancora para começo da página">Home</a></li>
			<li class="list_item"><a href="#atracoes" title="Ancora para a seção dos Parques">Parques</a></li>
			<li class="list_item"><a href="https://privehoteiseparques.com.br/" title="link para site de hospedagens">Onde Ficar</a></li>
			<li class="list_item"><a href="#promocao" title="Ancora para a seção 'Promoções'">Promoções</a></li>
			<li class="list_item"><a href="#localizacao" title="Ancora para a seção 'Como chegar'">Como Chegar</a></li>
			<li class="list_item"><a href="https://wam.group/politica-de-privacidade/" title="link para a Política de Privacidade">Política de Privacidade</a></li>
			<li class="list_item"><a href="faq.php" title="Ancora para a seção 'FAQ`s'">FAQ</a></li>
		</ul>
		<div class="spacer_box">
			<p>WAM Hotéis e Parques</p>
		</div>
	</div>
</div>
<!-- End menu lateral -->

<!-- Menu superior -->
<div class="menu-top">
	<center><a href="#"><img alt="Logo Privediversão" loading="lazy" class="logo" src="assets/img/logo-navbar.webp"></a></center>
</div>
<!-- End menu superior -->

<!-- Carousel de imagens home page -->
<div id="carouselExampleControls" class="carousel slide carousel-fade" data-bs-ride="carousel">
	<div class="carousel-inner">
		<?php
		$busca_slide = 'SELECT * FROM ' . $slide . ' WHERE status = 1 ORDER BY ordem';
		$query_slide = $connect->query($busca_slide);
		$count = 1;
		while ($result = $query_slide->fetch_assoc()) {
			if ($count == 1) { ?>
				<div data-bs-interval="3000" class="carousel-item active">
				<?php } else { ?>
					<div data-bs-interval="3000" class="carousel-item">
					<?php } ?>
					<img alt="<?php echo $result["descricao"] ?>" src="assets/img/<?php echo $result["url_img"] ?>" class="d-block w-100">
					</div>
				<?php $count++;
			} ?>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
	</div>
</div>
<!-- End carousel de imagens home page -->

<!-- Conheço nossos parques e atrações -->
<div class="row conheca" id="atracoes">
	<center>
		<h4 style="color: #f68c16; margin: 0px; line-height: 102%;">Confira Nossas Atrações</h4>
		<p style="margin-bottom: 20px; color: #000000bd; line-height: 102%;">Selecione um parque</p>
	</center>
	<div class="col-sm-12 div-logos">
		<div class="row">
			<div class="col-4 prive" id="logo-prive" style="opacity: 1;">
				<div class="logo-conheca">
					<span id="chevron-atracao-prive" onclick="showatracoes('prive')">
						<img loading="lazy" src="assets/img/clubePriveAzul.webp" alt="Logo Clube Privé">
					</span>
				</div>
				<div class="buttons-veja-atracoes">
					<span id="chevron-atracao-prive" onclick="showatracoes('prive')">
						<svg id="chevron-prive" style="display: none;" class="chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
							<!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
							<path d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
						</svg>
					</span>
				</div>
				<hr id="hr-prive" style="background: #f68c16; opacity: 1; color: #f68c16">
			</div>
			<div class="col-4 water-park" id="logo-waterpark" style="opacity: 0.5;">
				<div class="logo-conheca">
					<span id="chevron-atracao-waterpark" onclick="showatracoes('waterpark')">
						<img loading="lazy" src="assets/img/waterpark.webp" alt="Logo Water Park">
					</span>
				</div>
				<div class="buttons-veja-atracoes">
					<span id="chevron-atracao-waterpark" onclick="showatracoes('waterpark')">
						<svg id="chevron-waterpark" class="chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
							<!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
							<path d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
						</svg>
					</span>
				</div>
				<hr id="hr-waterpark" style="background: #f68c16; opacity: 0; color: #f68c16">
			</div>
			<div class="col-4 nautico" id="logo-nautico" style="opacity: 0.5;">
				<div class="logo-conheca">
					<span id="chevron-atracao-nautico" onclick="showatracoes('nautico')">
						<img loading="lazy" src="assets/img/nautico.webp" alt="Logo Náutico">
					</span>
				</div>
				<div class="buttons-veja-atracoes">
					<span id="chevron-atracao-nautico" onclick="showatracoes('nautico')">
						<svg id="chevron-nautico" class="chevron" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
							<!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
							<path d="M233.4 105.4c12.5-12.5 32.8-12.5 45.3 0l192 192c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L256 173.3 86.6 342.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l192-192z" />
						</svg>
					</span>
				</div>
				<hr id="hr-nautico" style="background: #f68c16; opacity: 0; color: #f68c16">
			</div>
		</div>
	</div>
	<div class="col-sm-12" style="padding: 0px;">
		<div class="imagens">
			<div id="carouselExampleIndicatorsprive" class="carousel slide mostraatracao" data-bs-ride="carousel">
				<div class="carousel-inner">
					<?php
					$busca_atracao_prive = 'SELECT * FROM atracoes WHERE id_parque = 1 AND status = 1 ORDER BY ordem';
					$query_atracao_prive = $connect->query($busca_atracao_prive);
					$count = 1;
					while ($result = $query_atracao_prive->fetch_assoc()) {
						if ($count == 1) { ?>
							<div class="carousel-item active">
							<?php } else { ?>
								<div class="carousel-item">
								<?php } ?>
								<img loading="lazy" src="assets/img/<?php echo $result['url_img']; ?>" alt="Imagem da atração <?php echo $result["nome"] ?>">
								<div class="text-brinquedos">
									<h4><?php echo $result['nome']; ?></h4>
									<h5><?php echo $result['descricao']; ?><br><br>
										Horário de funcionamento: <br><b><?php echo $result['hr_abert']; ?>hr às <?php echo $result['hr_fecha']; ?>hr</b><br><br>
										Categoria: <br><b><?php echo $result['categoria']; ?></b>
									</h5>
								</div>
								</div>
							<?php $count++;
						} ?>
							<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicatorsprive" data-bs-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="visually-hidden">Previous</span>
							</button>
							<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicatorsprive" data-bs-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="visually-hidden">Next</span>
							</button>
							</div>
				</div>
			</div>
		</div>
		<div class="col-sm-12" style="padding: 0px;">
			<div class="imagens">
				<div id="carouselExampleIndicatorswaterpark" class="carousel slide escondeatracao" data-bs-ride="carousel">
					<div class="carousel-inner">
						<?php
						$busca_atracao_waterpark = 'SELECT * FROM atracoes WHERE id_parque = 2 AND status = 1 ORDER BY ordem';
						$query_atracao_waterpark = $connect->query($busca_atracao_waterpark);
						$count = 1;
						while ($result = $query_atracao_waterpark->fetch_assoc()) {
							if ($count == 1) { ?>
								<div class="carousel-item active">
								<?php } else { ?>
									<div class="carousel-item">
									<?php } ?>
									<img loading="lazy" src="assets/img/<?php echo $result['url_img']; ?>" alt="Imagem da atração <?php echo $result["nome"] ?>">
									<div class="text-brinquedos">
										<h4><?php echo $result['nome']; ?></h4>
										<h5><?php echo $result['descricao']; ?><br><br>
											Horário de funcionamento: <br><b><?php echo $result['hr_abert']; ?>hr às <?php echo $result['hr_fecha']; ?>hr</b><br><br>
											Categoria: <br><b><?php echo $result['categoria']; ?></b>
										</h5>
									</div>
									</div>
								<?php $count++;
							} ?>
								<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicatorswaterpark" data-bs-slide="prev">
									<span class="carousel-control-prev-icon" aria-hidden="true"></span>
									<span class="visually-hidden">Previous</span>
								</button>
								<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicatorswaterpark" data-bs-slide="next">
									<span class="carousel-control-next-icon" aria-hidden="true"></span>
									<span class="visually-hidden">Next</span>
								</button>
								</div>
					</div>
				</div>
			</div>
			<div class="col-sm-12" style="padding: 0px;">
				<div class="imagens">
					<div id="carouselExampleIndicatorsnautico" class="carousel slide escondeatracao" data-bs-ride="carousel">
						<div class="carousel-inner">
							<?php
							$busca_atracao_nautico = 'SELECT * FROM atracoes WHERE id_parque = 3 AND status = 1 ORDER BY ordem';
							$query_atracao_nautico = $connect->query($busca_atracao_nautico);
							$count = 1;
							while ($result = $query_atracao_nautico->fetch_assoc()) {
								if ($count == 1) { ?>
									<div class="carousel-item active">
									<?php } else { ?>
										<div class="carousel-item">
										<?php } ?>
										<img loading="lazy" src="assets/img/<?php echo $result['url_img']; ?>" alt="Imagem da atração <?php echo $result["nome"] ?>">
										<div class="text-brinquedos">
											<h4><?php echo $result['nome']; ?></h4>
											<h5><?php echo $result['descricao']; ?><br><br>
												Horário de funcionamento: <br><b><?php echo $result['hr_abert']; ?>hr às <?php echo $result['hr_fecha']; ?>hr</b><br><br>
												Categoria: <br><b><?php echo $result['categoria']; ?></b>
											</h5>
										</div>
										</div>
									<?php $count++;
								} ?>
									<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicatorsnautico" data-bs-slide="prev">
										<span class="carousel-control-prev-icon" aria-hidden="true"></span>
										<span class="visually-hidden">Previous</span>
									</button>
									<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicatorsnautico" data-bs-slide="next">
										<span class="carousel-control-next-icon" aria-hidden="true"></span>
										<span class="visually-hidden">Next</span>
									</button>
									</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End conheço nossos Parques -->

		<div class="newsletter row" id="newsletter">
			<form action="controle/assets/functions/insert.php" method="post" enctype="multipart/form-data">
				<div class="col-12 news-text"><h4>Inscreva-se para receber <span> nossos conteúdos</span></h4></div>
				<input type="text" name="name" value=" " style="display: none;">
				<input type="text" name="phone" value=" " style="display: none;">
				<input type="text" name="message" value=" " style="display: none;">
				<input type="text" name="acao" value="newsletter" style="display: none;">
				<div class="col-7 news-email"><input type="text" class="news-input" name="email" placeholder="Seu E-Mail" required=""></div>
				<div class="col-5 news-div-button"><button type="submit" class="news-button">Cadastrar</button></div>
			</form>
		</div>

		<!-- Promoções -->
		<div class="row" id="promocao">
		<?php
			$busca_promocao = 'SELECT * FROM promocao WHERE status = 1';
			$query_promocao = $connect->query($busca_promocao);
			while ($result = $query_promocao->fetch_assoc()) { ?>
			<center>
				<h4> <?php echo $result["titulo"] ?></h4>
			</center>
				<section style="padding: 0%;margin: 0%;">
					<div class="container bg-atracao">
						<div class="row no-gutters nautico-atracao">
							<img loading="lazy" class="img-atracao" src="assets/img/<?php echo $result["url_img"] ?>" alt="Imagem de promoção no site">
							<a style="margin-top: -20px;" href="<?php echo $result["link"] ?>"><button class="saiba-mais"><?php echo $result["text_button"] ?></button></a>
						</div>
					</div>
				</section>
			<?php } ?>
		</div>
		<!-- End promoções -->
		<div class="row" style="padding-bottom: 30px!important;">
			<center>
				<h4 style="padding: 30px; color: #f68c16; margin: 0px;"> Confira o Instagram
					<a href="https://www.instagram.com/privediversao/" title="Logo instagram">
						<img width="30px" src="assets/img/instagram.png">
					</a>
				</h4>
			</center>
			<div class="col-12 col-sm-12 col-md-12 col-xxl-12 col-xl-12 col-lg-12">
				<div class="row" id="insta"></div>
			</div>
			<center>
				<button type="button" class="seguir" href="https://www.instagram.com/privediversao/">Siga! @privediversao</button>
			</center>
		</div>

		<!-- Como chegar -->
		<div class="row loc-pt-1" id="localizacao">
			<div class="col-sm-12">
				<center>
					<h4>Localizações</h4>
				</center>
			</div>
		</div>
		<div class="col-12" style="overflow: hidden;" class="mapa" id="overlay">
			<center>
				<iframe load="lazy" class="maps" id="map" src="https://www.google.com/maps/d/embed?mid=1EyR4uAN_kwQbU1WSjIVI6ML5bfDBHIM&ehbc=fff" title="Mapa com as localizações dos parques do Privé Diversão"></iframe>
			</center>
		</div>
		<!-- End como chegar -->

		<!-- Footer -->
		<footer>
			<div class="row">
				<div class="col-3" style="padding: 0%">
					<?php
					$buscar_rodape = 'SELECT * FROM rodape LIMIT 1';
					$query_rodape = $connect->query($buscar_rodape);
					if ($query_rodape != false) {
						$result = $query_rodape->fetch_assoc();
						if (count($result) != 0) {
					?>
							<img loading="lazy" class="logo-footer" src="assets/img/<?php echo $result["url_img_logo"]; ?>" alt="Logo Privediversão">
				</div>
				<div class="col-9" style="padding: 0%">
					<div class="row text-footer" style="padding: 0%">
						<div class="col-12" style="padding: 0%">
						</div>
						<div class="col-12 text-info">
							<center>
								<p>
									<svg style="max-width: 10px;" fill="#4c4c73" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" alt="Logo facebook">
										<!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
										<path d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z" />
									</svg>
									<?php echo $result["telefone"] ?>
								</p>
								<p>
									<svg style="max-width: 10px;" fill="#4c4c73" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" alt="Logo facebook">
										<!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
										<path d="M64 112c-8.8 0-16 7.2-16 16v22.1L220.5 291.7c20.7 17 50.4 17 71.1 0L464 150.1V128c0-8.8-7.2-16-16-16H64zM48 212.2V384c0 8.8 7.2 16 16 16H448c8.8 0 16-7.2 16-16V212.2L322 328.8c-38.4 31.5-93.7 31.5-132 0L48 212.2zM0 128C0 92.7 28.7 64 64 64H448c35.3 0 64 28.7 64 64V384c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128z" />
									</svg>
									<?php echo $result["email"] ?>
								</p>
								<p><?php echo $result["text_info"] ?></p>
								<h6 class="copyright">&#169;Todos os direitos reservados. Privé Diversão 2022</h6>
							</center>
						</div>
					</div>
				</div>
		<?php }
					} ?>
			</div>
		</footer>
		<!-- End Footer -->

		<!-- Botão flutuante "compre seu ingresso" -->
		<a href="https://ingressos.privediversao.com.br/#/">
			<div class="ingresso" id="ingresso">
				<p>Compre seu ingresso agora! <img loading="lazy" class="icon-dedo" src="assets/img/dedo.webp" alt="ícone de clique"></p>
			</div>
		</a>
		<!-- End flutuante "compre seu ingresso" -->

		<!-- Botão flutuante WhatsApp -->
		<a href="https://api.whatsapp.com/send?phone=556434548400" title="link para conversar com suporte pelo WhatsApp"><img loading="lazy" class="btn-whatsapp" src="assets/img/whatsapp-logo.webp" alt="Ícone do WhatsApp"></a>
		<!-- End flutuante WhatsApp -->

		<!-- WEB CHAT -->
		<script>
			window.renderBotWidget(
				'639094e3a4425e0019058704'
			);
		</script>

		</body>
		<?php
		if (isset($_GET["sucesso"])) {
			echo "<script>alert('E-mail cadastrado com sucesso!')</script>";
		} else if (isset($_GET["erro"])) {
			echo "<script>alert('Alguma coisa deu errado, tente novamente mais tarde.')</script>";
		}
		?>

</html>