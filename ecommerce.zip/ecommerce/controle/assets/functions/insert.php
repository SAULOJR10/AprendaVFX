<?php

require_once "../../../assets/bib/conexao.php";
$retorno = explode('?', $_SERVER['HTTP_REFERER'])[0];

session_start();

if (isset($_POST['acao'])) {
    switch ($_POST['acao']) {
        case 'slide_mobile':
            insert_slide_mobile();
            break;
        case 'slide_pc':
            insert_slide_pc();
            break;
        case 'atracao':
            insert_atracao();
            break;
        case 'promocao':
            insert_promocao();
            break;
        case 'pergunta':
            insert_pergunta();
            break;
        case 'rodape':
            insert_rodape();
            break;
        case 'usuario':
            insert_usuario();
            break;
        case 'newsletter':
            insert_newsletter();
            break;
            case 'rastreamento':
                insert_rastreamento();
                break;
    }
} else {
    header("location: " . $retorno . '?erro=');
    exit;
}

function insert_slide_pc()
{
    global $retorno;
    global $connect;
    $img = move_file($_FILES["img"]);
    $desc = $_POST["desc"];
    $order = $_POST["order"];
    $status = $_POST["status"];

    $sql = "INSERT INTO slide_home_pc (url_img, descricao, ordem, status) VALUES ('$img','$desc','$order','$status')";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function insert_slide_mobile()
{
    global $retorno;
    global $connect;
    $img = move_file($_FILES["img"]);
    $desc = $_POST["desc"];
    $order = $_POST["order"];
    $status = $_POST["status"];

    $sql = "INSERT INTO slide_home_mobile (url_img, descricao, ordem, status)
            VALUES ('$img','$desc','$order','$status')";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=1');
    }
}

function insert_atracao()
{
    global $retorno;
    global $connect;
    $img = move_file($_FILES["img"]);
    $title = $_POST["title"];
    $desc = $_POST["desc"];
    $hr_abert = $_POST["hr_abert"];
    $hr_fecha = $_POST["hr_fecha"];
    $cat = $_POST["cat"];
    $order = $_POST["order"];
    $id_parque = $_POST["parque"];

    $sql = "INSERT INTO `atracoes`(`id_parque`, `url_img`, `nome`, `descricao`, `categoria`, `hr_abert`, `hr_fecha`, `ordem`, `status`)
            VALUES ('$id_parque','$img','$title','$desc','$cat','$hr_abert','$hr_fecha','$order', 1)";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function insert_promocao()
{
    global $retorno;
    global $connect;
    $img = move_file($_FILES["img"]);
    $title = $_POST["title"];
    $botao = $_POST["botao"];
    $link = $_POST["link"];
    $descricao = $_POST["descricao"];

    $sql = "INSERT INTO `promocao`(`url_img`, `titulo`, `link`, `descricao` `text_button`, `status`)
            VALUES ('$img','$title','$link', '$descricao', '$botao', 1)";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function insert_rodape()
{
    global $retorno;
    global $connect;
    $img = move_file($_FILES["img"]);
    $info = $_POST["info"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];

    $sql = "INSERT INTO `rodape`(`url_img_logo`, `text_info`, `telefone`, `email`)
            VALUES ('$img','$info','$telefone','$email')";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function insert_pergunta()
{
    global $retorno;
    global $connect;
    $pergunta = $_POST["pergunta"];
    $resposta = $_POST["resposta"];
    $tipo = $_POST["tipo"];

    $sql = "INSERT INTO `faq`(`pergunta`, `resposta`, `tipo_faq`, `status`)
            VALUES ('$pergunta','$resposta','$tipo',1)";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function insert_usuario()
{
    global $retorno;
    global $connect;

    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $cep = $_POST["cep"];
    $telefone = $_POST["telefone"];
    $nascimento = $_POST["nascimento"];
    $email = $_POST["email"];

    $login = $_POST["login"];
    $nivel = $_POST["nivel"];
    $senha = $_POST["senha"];
    $confirmar = $_POST["confirmar"];

    if ($senha != $confirmar) {
        header("location: " . $retorno . '?erro=Senhas não coincidem');
    } else {
        $senha = md5($senha);
    }

    $sql_busca = "SELECT * FROM usuario INNER JOIN login ON usuario.id_login = login.id WHERE email = '$email' OR login = '$login' OR cpf = '$cpf' OR telefone = '$telefone'";
    $query_busca = $connect->query($sql_busca);
    $resultado = $query_busca->fetch_assoc();

    if ($resultado != null) {
        switch ($resultado) {
            case $resultado["email"] == $email:
                header("location: " . $retorno . '?erro=E-mail já cadastrado');
                exit;
                break;
            case $resultado["login"] == $login:
                header("location: " . $retorno . '?erro=Login já é utilizado');
                exit;
                break;
            case $resultado["cpf"] == $cpf:
                header("location: " . $retorno . '?erro=CPF já cadastrado');
                exit;
                break;
            case $resultado["telefone"] == $telefone:
                header("location: " . $retorno . '?erro=Telefone já cadastrado');
                exit;
                break;
        }
    } else {
        $sql_login = "INSERT INTO `login`(`login`, `senha`, `nivel`, `status`)
                      VALUES ('$login','$senha','$nivel', 1)";
        if ($connect->query($sql_login)) {
            $sql_id = "SELECT MAX(id) as id FROM login";
            $query_id = $connect->query($sql_id);
            $id_login = mysqli_fetch_assoc($query_id)["id"];
            $sql_usuario = "INSERT INTO `usuario`(`nome`, `cpf`, `cep`, `telefone`, `email`, `data_nascimento`, `id_login`)
                                    VALUES ('$nome','$cpf','$cep','$telefone','$email','$nascimento','$id_login')";
            if ($connect->query($sql_usuario)) {
                header("location: " . $retorno . '?sucesso=');
            }
        }
    }
}

function insert_newsletter()
{
    global $retorno;
    global $connect;

    $email = $_POST['email'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];
    $data = date('d/m/Y H:i');
    $data_envio = date('d/m/Y');
    $hora_envio = date('H:i:s');
    $sql_newsletter = "INSERT INTO `newsletter` (`email`, `data`, `aprovacao`, `telefone`, `nome`, `mensagem`, `status`)
                      VALUES ('$email','$data', 0, '$phone', '$name', '$message', 1)";

    $arquivo = "
        <style type='text/css'>
            body {
            margin:0px;
            font-family:Verdane;
            font-size:12px;
            color: #666666;
            }
            a{
            color: #666666;
            text-decoration: none;
            }
            a:hover {
            color: #FF0000;
            text-decoration: none;
            }
        </style>
        <html>
            <table width='510' border='1' cellpadding='1' cellspacing='1' bgcolor='#CCCCCC'>
                <tr>
                    <td>
                        <tr>
                            <td width='320'>E-mail:<b>$email</b></td>
                        </tr>
                    </td>
                </tr>
                <tr>
                    <td>Este e-mail foi enviado em <b>$data_envio</b> às <b>$hora_envio</b></td>
                </tr>
                </table>
        </html>";


    $emailenviar = "saulo.junior@privediversao.com.br";
    $destino = $emailenviar;
    $assunto = "News Letter pelo site";

    // É necessário indicar que o formato do e-mail é html
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From: $nome <$email>';
    //$headers .= "Bcc: $EmailPadrao\r\n";

    if(!mail($destino, $assunto, $arquivo, $headers)) {
        header("location: " . $retorno . '?erro='); 
    }
    if ($connect->query($sql_newsletter)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function insert_rastreamento()
{
    global $connect;
    $last_url = $_SERVER['HTTP_REFERER'];
    $data = date('d/m/Y H:i');
    $sql_rastreamento = "INSERT INTO rastreamento (link_anterior, data) VALUES ('$last_url', '$data')";
    $connect->query($sql_rastreamento);

    header("location: ../../../");
}

function move_file($arquivo)
{
    global $retorno;
    if (!empty($_FILES['img']) || !$_FILES["img"]["name"] != "") {
        //MOVE FILE
        $ext = strtolower(substr($arquivo['name'], -4)); //Pegando extensão do arquivo
        if ($ext = "webp") {
            $ext = ".webp";
        }
        $img = date("Y.m.d-H.i.s") . $ext; //Definindo um novo nome para o arquivo
        $dir = '../../../assets/img/'; //Diretório para uploads
        if (!move_uploaded_file($_FILES['img']['tmp_name'], $dir . $img)) { //Fazer upload do arquivo
            header("location: " . $retorno . '?erro=');
            exit;
        } //se não fizer upload, retorna erro

        return $img;
    } else {
        header("location: " . $retorno . '?erro=');
    }
}
