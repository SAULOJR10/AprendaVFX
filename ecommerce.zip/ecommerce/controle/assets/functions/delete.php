<?php
require_once "../../../assets/bib/conexao.php";
$retorno = explode('?', $_SERVER['HTTP_REFERER'])[0];

session_start();

if (isset($_POST['acao'])) {
    switch ($_POST['acao']) {
        case 'exclui':
            delete();
            break;
        case 'exclui_login':
            delete_login();
            break;
    }
} else {
    header("location: ../../index.php");
    exit;
}

function delete()
{
    global $connect;
    $id = $_POST["id"];
    $tabela = $_POST["tabela"];

    $seleciona_img = "SELECT * FROM $tabela WHERE id = $id";
    $query_img = $connect->query($seleciona_img);
    if ($query_img != false) {
        $result = $query_img->fetch_assoc();
        $img = $result["url_img"];

        $base_dir = realpath($_SERVER["DOCUMENT_ROOT"]) . "/homologacao/ecommerce/assets/img/" . $img;

        if (file_exists($base_dir) && $img != "") {
            unlink($base_dir);
        }
    }
    $sql = "DELETE FROM `$tabela` WHERE id=$id";

    if ($connect->query($sql)) {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?sucesso=');
    } else {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?erro=');
    }
}

function delete_login()
{
    global $connect;
    $id = $_POST["id"];

    $sql = "DELETE FROM `login` WHERE id=$id";
    $sql2 = "DELETE FROM `usuario` WHERE id_login=$id";

    if ($connect->query($sql) && $connect->query($sql2)) {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?sucesso=');
    } else {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?erro=');
    }
}
