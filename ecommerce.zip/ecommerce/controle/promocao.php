<?php
require_once "../assets/bib/conexao.php";

if (!isset($_SESSION)) session_start();

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID'])) {
    // Destrói a sessão por segurança
    session_destroy();
    // Redireciona o visitante de volta pro login
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- ----------Importa head---------- -->
    <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
    <!-- Importa menus lateral e superior -->
    <?php if ($_SESSION["UsuarioNivel"] == "cl") {
        require_once "menus.php";
    } else {
        require_once "menus_adm.php";
    }
    ?>

    <div class="content-controle">
        <div class="card">
            <div class="text">
                <h4>Promoção</h4>
                <?php if (!isset($_GET['id'])) { ?>
                    <form action="assets/functions/insert.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="promocao" style="display: none;">
                        <label class="metade">Imagem:
                            <label class="label_file"><span id="value_file">Arquivo</span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img">
                            </label>
                        </label>
                        <label class="metade">Botão:
                            <input class="button" type="text" name="botao" placeholder="Texto" required="">
                        </label>
                        <label>Titulo:
                            <input class="title" value="titulo" type="text" name="title" placeholder="Titulo da seção" required="">
                        </label>
                        <label>Link:
                            <input class="link" id="link" type="text" name="link" placeholder="Link da promoção" required="">
                        </label>
                        <label>Descrição:
                            <input class="resposta" id="descricao" type="text" name="descricao" placeholder="Descrição da promoção" required="">
                        </label>
                        <button type="submit" class="enviar">Enviar</button>
                    </form>
                <?php } else if ($_GET['id'] != '') {
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM promocao WHERE id = $id LIMIT 1";
                    $query_slide = $connect->query($sql);
                    $resultado = $query_slide->fetch_assoc();
                ?>
                    <form action="assets/functions/update.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="promocao" style="display: none;">
                        <input type="text" name="id" value="<?php echo $_GET['id']; ?>" style="display: none;">
                        <label class="metade">Imagem:
                            <input style="display: none;" value="<?php echo $resultado['url_img']; ?>" type="text" name="img_text">
                            <label class="label_file"><span id="value_file"><?php echo $resultado['url_img']; ?></span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img">
                            </label>
                        </label>
                        <label class="metade">Botão:
                            <input class="button" type="text" value="<?php echo $resultado['text_button']; ?>" name="botao" placeholder="Texto do botão" required="">
                        </label>
                        <label>Titulo:
                            <input class="title" value="<?php echo $resultado['titulo']; ?>" type="text" name="title" placeholder="Titulo da seção" required="">
                        </label>
                        <label>Link:
                            <input class="link" id="link" type="text" value="<?php echo $resultado['link']; ?>" name="link" placeholder="Link da promoção" required="">
                        </label>
                        <label>Descrição:
                            <input class="resposta" id="descricao" type="text" value="<?php echo $resultado['descricao']; ?>" name="descricao" placeholder="Descrição da promoção" required="">
                        </label>
                        </label>
                        <button type="submit" style="background-color: #0c0;" class="enviar">Atualizar</button>
                    </form>
                <?php } ?>
            </div>
        </div>
        <div class="card" style="width: 99%; margin-top: 20px; padding: 40px 5px;">
            <h4>Promoções Cadastradas</h4>
            <hr>
            <div class="text">
                <table>
                    <tbody>
                        <tr>
                            <th>Id</th>
                            <th>Imagem</th>
                            <th>Texto botão</th>
                            <th>Link Botão</th>
                            <th>Editar</th>
                            <th>Ativar / Desativar</th>
                            <th>Excluir</th>
                        </tr>
                        <?php $busca_slide = 'SELECT * FROM promocao ORDER BY status';
                        $query_slide = $connect->query($busca_slide);
                        $count = 1;
                        $tabela = "";
                        while ($result = $query_slide->fetch_assoc()) {
                            $id = $result['id'];
                            $img = $result['url_img'];
                            $titulo = $result['titulo'];
                            $text_button = $result['text_button'];
                            $link = $result['link'];
                            $status = $result['status'];
                            $tabela .= "<tr>
                                        <td>$id</td>
                                        <td><img src='../assets/img/$img' style='max-width: 120px;'></td>
                                        <td>$text_button</td>
                                        <td>$link</td>
                                        <td><a href='promocao.php?id=$id'><img src='../assets/img/edit.svg' style='max-width: 20px;'></a></td>
                                        ";
                            if ($status == 1) {
                                $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='desativa' name='acao' style='display: none;'>
                                                <input type='text' value='promocao' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/ativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                            } else {
                                $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='ativa' name='acao' style='display: none;'>
                                                <input type='text' value='promocao' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/desativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                            }
                            $tabela .= "<td>
                                            <form action='assets/functions/delete.php' id='form$id'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='exclui' name='acao' style='display: none;'>
                                                <input type='text' value='promocao' name='tabela' style='display: none;'>
                                                <button type='button' onclick='confirmar($id)' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/lixo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";
                        }
                        echo $tabela;
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
    if (isset($_GET["sucesso"])) {
        echo "<script>alert('Sucesso!!!')</script>";
    } else if (isset($_GET["erro"])) {
        echo "<script>alert('Alguma coisa deu errado, tente novamente mais tarde.')</script>";
    }
    ?>
</body>

</html>