<?php
require_once "../assets/bib/conexao.php";

if (!isset($_SESSION)) session_start();

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID'])) {
    // Destrói a sessão por segurança
    session_destroy();
    // Redireciona o visitante de volta pro login
    header("Location: login.php");
    exit;
}
if ($_SESSION["UsuarioNivel"] != "adm") {
    $retorno = explode('?', $_SERVER['HTTP_REFERER'])[0];
    header("Location: $retorno");
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- ----------Importa head---------- -->
    <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
    <!-- Importa menus lateral e superior -->
    <?php if ($_SESSION["UsuarioNivel"] == "cl") {
        require_once "menus.php";
    } else {
        require_once "menus_adm.php";
    }
    ?>
    <!-- -------------------------------- -->
    <?php
    if ($_GET['id'] != '') {
        $id = $_GET['id'];
        $sql = "SELECT * FROM newsletter WHERE id = $id LIMIT 1";
        $query_slide = $connect->query($sql);
        $resultado = $query_slide->fetch_assoc();
    ?>
        <div class="content-controle">
            <div class="card">
                <div class="text">
                    <h4>Newsletter</h4>
                    <form action="assets/functions/update.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="newsletter" style="display: none;">
                        <input type="text" name="id" value="<?php echo $_GET['id']; ?>" style="display: none;">
                        <label>email:
                            <input class="email" value="<?php echo $resultado['email']; ?>" type="text" name="email" placeholder="E-mail" required="">
                        </label>
                        <label>Nome:
                            <input class="user" value="<?php echo $resultado['nome']; ?>" type="text" name="name" placeholder="Nome" required="">
                        </label>
                        <label>Telefone:
                            <input class="telefone" value="<?php echo $resultado['telefone']; ?>" type="text" name="phone" placeholder="Telefone" required="">
                        </label>
                        <label>Mensagem:
                            <input class="resposta" value="<?php echo $resultado['mensagem']; ?>" type="text" name="message" placeholder="Mensagem" required="">
                        </label>
                        <label>Aprovação:
                            <select class="aprovacao" id="aprovacao" name="aprovacao" placeholder="Aprovação" require="">
                                <?php if($status == 1){ ?>
                                    <option value="1" selected>APROVADO</option>
                                    <option value="2">REPROVADO</option>
                                <?php }else{ ?>
                                    <option value="1">APROVADO</option>
                                    <option value="2" selected>REPROVADO</option>
                                <?php } ?>
                            </select>
                        </label>
                        <button type="submit" style="background-color: #0c0;" class="enviar">Atualizar</button>
                    </form>
                </div>
            </div>
        <?php } ?>

        <div class="content-controle">
            <div class="card" style="width: 99%; margin-top: 20px; padding: 40px 5px;">
                <h4>Newsletter Cadastradas</h4>
                <hr>
                <div class="text">
                    <table>
                        <tbody>
                            <tr>
                                <th>Id</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Data</th>
                                <th>Aprovação</th>
                                <th>Editar</th>
                                <th>Status</th>
                                <th>Eliminar</th>
                            </tr>
                            <?php
                            $busca_newsletter = 'SELECT * FROM newsletter';
                            $query_newsletter = $connect->query($busca_newsletter);
                            $count = 1;
                            $tabela = '';
                            while ($result = $query_newsletter->fetch_assoc()) {
                                $id = $result['id'];
                                $email = $result['email'];
                                $nome = $result['nome'];
                                $data = $result['data'];
                                if($result['aprovacao'] == 1){
                                    $aprovacao = "<span style='color: green;'>Aprovado</span>";
                                }else{
                                    $aprovacao = "<span style='color: red;'>Reprovado</span>";
                                };
                                $status = $result['status'];
                                $tabela .= "<tr>
                                        <td>$count</td>
                                        <td>$nome</td>
                                        <td>$email</td>
                                        <td>$data</td>
                                        <td>$aprovacao</td>
                                        <td><a href='newsletter.php?id=$id'><img src='../assets/img/edit.svg' style='max-width: 20px;'></a></td>
                                        ";
                                if ($status == 1) {
                                    $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='desativa' name='acao' style='display: none;'>
                                                <input type='text' value='newsletter' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/ativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                                } else {
                                    $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='ativa' name='acao' style='display: none;'>
                                                <input type='text' value='newsletter' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/desativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                                }
                                $tabela .= "<td>
                                            <form action='assets/functions/delete.php' id='form$id'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='exclui' name='acao' style='display: none;'>
                                                <input type='text' value='newsletter' name='tabela' style='display: none;'>
                                                <button type='button' onclick='confirmar($id)' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/lixo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";
                                    $count++;
                            }
                            echo $tabela;
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
        if (isset($_GET["sucesso"])) {
            echo "<script>alert('Sucesso!!!')</script>";
        } else if (isset($_GET["erro"])) {
            $erro = $_GET["erro"];
            echo "<script>alert('$erro')</script>";
        }
        ?>
</body>

</html>