<!--- basic page needs
   ================================================== -->
<meta charset="utf-8">
<title>Painel de Controle</title>
<meta name="description" content="">
<meta name="author" content="SAULO COELHO DA COSTA JÚNIOR +55 (64) 99300-7836">

<!-- mobile specific metas
   ================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- favicons
	================================================== -->
<link rel="shortcut icon" href="../assets/img/favicon.webp">

<!-- CSS
   ================================================== -->
<link rel="stylesheet" href="../assets/css/bootstrap.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="assets/css/style.css">

<!-- script
   ================================================== -->
<script src="../assets/js/jquery.js"></script>
<script src="assets/js/jquery.mask.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/custom.js"></script>
<script src="assets/js/custom.js"></script>

<script>
   (function(w, d, s, l, i) {
      w[l] = w[l] || [];
      w[l].push({
         'gtm.start': new Date().getTime(),
         event: 'gtm.js'
      });
      var f = d.getElementsByTagName(s)[0],
         j = d.createElement(s),
         dl = l != 'dataLayer' ? '&l=' + l : '';
      j.async = true;
      j.src =
         'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
      f.parentNode.insertBefore(j, f);
   })(window, document, 'script', 'dataLayer', 'GTM-5D93CSS');
</script>

<script type="text/javascript">
   var analyticsFileTypes = [''];
   var analyticsSnippet = 'enabled';
   var analyticsEventTracking = 'enabled';
</script>
<script type="text/javascript">
   var _gaq = _gaq || [];

   _gaq.push(['_setAccount', 'UA-114439357-1']);
   _gaq.push(['_addDevId', 'i9k95']); // Google Analyticator App ID with Google
   _gaq.push(['_trackPageview']);

   (function() {
      var ga = document.createElement('script');
      ga.type = 'text/javascript';
      ga.async = true;
      ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(ga, s);
   })();
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11071276188"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'AW-11071276188');
	</script>

	<script>
		gtag('event', 'page_view', {
			'send_to': 'AW-11071276188',
			'value': 'replace with value',
			'items': [{
				'id': 'replace with value',
				'start_date': 'replace with value',
				'end_date': 'replace with value',
				'google_business_vertical': 'hotel_rental'
			}, {
				'origin': 'replace with value',
				'destination': 'replace with value',
				'start_date': 'replace with value',
				'end_date': 'replace with value',
				'google_business_vertical': 'travel'
			}, {
				'id': 'replace with value',
				'location_id': 'replace with value',
				'google_business_vertical': 'custom'
			}]
		});
	</script>