<?php
require_once "../assets/bib/conexao.php";

if (isset($_COOKIE["id"])) {
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<!-- Primary Meta Tags -->
<title>Privé Diversão | Parques em Caldas Novas | Site Oficial</title>
<meta name="title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
<meta name="description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://metatags.io/">
<meta property="og:title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
<meta property="og:description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
<meta property="og:image" content="https://metatags.io/assets/meta-tags-16a33a6a8531e519cc0936fbba0ad904e52d35f34a46c97a2c9f6f7dd7d336f2.png">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://metatags.io/">
<meta property="twitter:title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
<meta property="twitter:description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
<meta property="twitter:image" content="https://metatags.io/assets/meta-tags-16a33a6a8531e519cc0936fbba0ad904e52d35f34a46c97a2c9f6f7dd7d336f2.png">

<!--- basic page needs
   ================================================== -->
<meta charset="utf-8">
<meta name="description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
<meta name="author" content="SAULO COELHO DA COSTA JUNIOR +55 (64) 99300-7836">
<meta name="keywords" content="parques, aquático, diversão, Caldas Novas, parque aquático, parque de diversão, water park, nautico, privé, clube, resort, prive">
<meta name="robots" content="index, follow">
<meta name="canonical" content="https://privediversao.com.br">
<meta name="sitemap" type="application/xml" href="./sitemap.xml">

<!-- mobile specific metas
   ================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- Site Icons -->
<link rel="shortcut icon" href="images/favicon.webp" type="image/x-icon" />
<link rel="apple-touch-icon" href="images/favicon.webp">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="css/custom.css">
<script src="js/modernizr.js"></script>
<!-- Modernizr -->

<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start': new Date().getTime(),
				event: 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0],
				j = d.createElement(s),
				dl = l != 'dataLayer' ? '&l=' + l : '';
			j.async = true;
			j.src =
				'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-5D93CSS');
	</script>

	<script type="text/javascript">
		var analyticsFileTypes = [''];
		var analyticsSnippet = 'enabled';
		var analyticsEventTracking = 'enabled';
	</script>
	<script type="text/javascript">
		var _gaq = _gaq || [];

		_gaq.push(['_setAccount', 'UA-114439357-1']);
		_gaq.push(['_addDevId', 'i9k95']); // Google Analyticator App ID with Google
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script');
			ga.type = 'text/javascript';
			ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0];
			s.parentNode.insertBefore(ga, s);
		})();
	</script>

    <!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11071276188"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'AW-11071276188');
	</script>

	<script>
		gtag('event', 'page_view', {
			'send_to': 'AW-11071276188',
			'value': 'replace with value',
			'items': [{
				'id': 'replace with value',
				'start_date': 'replace with value',
				'end_date': 'replace with value',
				'google_business_vertical': 'hotel_rental'
			}, {
				'origin': 'replace with value',
				'destination': 'replace with value',
				'start_date': 'replace with value',
				'end_date': 'replace with value',
				'google_business_vertical': 'travel'
			}, {
				'id': 'replace with value',
				'location_id': 'replace with value',
				'google_business_vertical': 'custom'
			}]
		});
	</script>

<!-- WEB CHAT -->
<link rel="stylesheet" href="https://app.boteria.com.br/cdn/webchat/webchat.v2.css" />
<script src="https://app.boteria.com.br/cdn/libs/showdown.min.js"></script>
<script src="https://app.boteria.com.br/cdn/libs/axios.js"></script>
<script src="https://app.boteria.com.br/cdn/libs/socket.io.js"></script>
<script src="https://app.boteria.com.br/cdn/webchat/webchat.js"></script>

</head>

<?php
if (!isset($_COOKIE['largeur']) || $_COOKIE['largeur'] == '' || $_COOKIE['largeur'] == 'deleted') {
	echo "<body onload='disp()' id='page-top' class='politics_version'>";
} else {
	// Código para exibir em caso de detecção da resolução de exibição
	if ($_COOKIE['largeur'] > 700) {
		$slide = 'slide_home_pc';
	} else {
		$slide = 'slide_home_mobile';
	}

	$key = "largeur";
	$path = '';
	$domain = '';
	$secure = false;
	if (isset($_COOKIE['largeur'])) {
		unset($_COOKIE[$key]);
	}
	echo "<body id='page-top' class='politics_version'>";
}
?>

    <!-- LOADER -->
    <div id="preloader">
        <div id="main-ld">
            <div id="loader"></div>
        </div>
    </div>
    <!-- end loader -->
    <!-- END LOADER -->

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">
                <img class="img-fluid" style="max-width: 100px;" src="images/logo.webp" alt="" />
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fa fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav text-uppercase ml-auto">
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger active" href="#inicio">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#promocao">Promoções</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#newsletters">Newsletter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#atracao">Atrações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#contato">Contato</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="https://ingressos.privediversao.com.br/#/">Ingresso</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="inicio" class="main-banner parallaxie" style="background: url('../assets/img/layer_2.webp')">
        <div class="heading">
            <h1>Conheça o <u>Privé Diversão</u></h1>
            <!-- <h3 class="cd-headline clip is-full-width"><span style="line-height: 30px;">Três parques incríveis para você e sua família aproveitar inúmeras <br> atrações e desfrutar dos melhores dias de suas vidas.</span></h3> -->
            <h3 class="cd-headline clip is-full-width">
                <span>Aproveite</span>
                <span class="cd-words-wrapper">
                    <b class="is-visible">Piscinas Termais.</b>
                    <b>Toboáguas radicais.</b>
                    <b>Zonas infantis.</b>
                    <b>Passeios de tirar o fôlego.</b>
                </span>
            </h3>
        </div>
    </section>

    <div id="promocao" class="section wb">
        <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <?php
                    $busca_promocao = 'SELECT * FROM promocao WHERE status = 1';
                    $query_promocao = $connect->query($busca_promocao);
                    $quantidade = mysqli_num_rows($query_promocao);
                    for ($i = 0; $i < $quantidade; $i++) { ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo $i; ?>" <?php if ($i == 0) { ?> class="active" <?php } ?>></li>
                    <?php } ?>
                </ol>
                <div class="carousel-inner">
                    <?php
                    $contador = 1;
                    $busca_promocao = 'SELECT * FROM promocao WHERE status = 1';
                    $query_promocao = $connect->query($busca_promocao);
                    while ($result = $query_promocao->fetch_assoc()) { ?>
                        <div class="carousel-item <?php if ($contador == 1) { ?> active <?php } ?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="message-box" style="min-height: 200px;">
                                        <h2><?php echo $result["titulo"] ?></h2>
                                        <p><?php echo $result["descricao"] ?></p>
                                        <a href="<?php echo $result["link"] ?>" class="sim-btn btn-hover-new" data-text="<?php echo $result["text_button"] ?>">
                                            <span>
                                                <?php echo $result["text_button"] ?>
                                            </span>
                                        </a>
                                    </div>
                                    <!-- end messagebox -->
                                </div>
                                <!-- end col -->

                                <div class="col-md-6">
                                    <div class="right-box-pro wow fadeIn">
                                        <center><img style="max-width: 350px; max-height: 350px;" src="../assets/img/<?php echo $result["url_img"] ?>" alt="" class="img-fluid img-rounded"></center>
                                    </div>
                                    <!-- end media -->
                                </div>
                                <!-- end col -->
                            </div>
                            <!-- end row -->
                        </div>
                    <?php $contador++; } ?>
                </div>
                <button class="carousel-control-prev" type="button" data-target="#carouselExampleIndicators" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-target="#carouselExampleIndicators" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </button>
            </div>
        </div>
        <!-- end container -->
    </div>
    <!-- end section -->
    <img src="images/ondaspc.png" class="img-top-newsletter" alt="">
    <div id="newsletters" class="section lb">
        <div class="container">
            <div class="section-title text-left">
                <h3>Newsletter</h3>
                <p>Para receber e-mail de todas nossas promoções, preencha o formulário abaixo.
                </p>
            </div>
            <!-- end title -->

            <form action="../controle/assets/functions/insert.php" method="post" enctype="multipart/form-data">
                <input type="text" name="acao" value="newsletter" style="display: none;">
                <div class="row">
                    <div class="col-md-3">
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <input class="form-control" id="name" name="name" type="text" placeholder="Seu nome." required="required" data-validation-required-message="Por favor insira seu nome.">
                            <p class="help-block text-danger"></p>
                        </div>
                        <div class="form-group">
                            <input class="form-control" id="email" name="email" type="text" placeholder="Seu e-mail." required="required" data-validation-required-message="Por favor insira seu e-mail.">
                            <p class="help-block text-danger"></p>
                        </div>
                        <div class="form-group">
                            <input class="form-control" id="phone" name="phone" type="text" placeholder="Seu celular" required="required" data-validation-required-message="Por favor insira seu celular.">
                            <p class="help-block text-danger"></p>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="message" name="message" placeholder="Sua mensagem">
                        </div>
                    </div>
                    <div class="col-md-3">
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-lg-12 text-center">
                        <div id="success"></div>
                        <button id="sendMessageButton" class="sim-btn btn-hover-new" data-text="Send Message" type="submit">Enviar</button>
                    </div>
                </div>
            </form>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <img src="images/ondaspc.png" class="img-bottom-newsletter">
    <!-- end section -->

    <div id="atracao" class="section lb">
        <div class="container">
            <div class="section-title text-left">
                <h3>Atrações</h3>
                <p>Conheça algumas das nossas atrações que fará seu passeio ser espetacular.
                </p>
            </div>
            <!-- end title -->

            <div class="gallery-menu row">
                <div class="col-md-12">
                    <div class="button-group filter-button-group text-left">
                        <center><button class="active" data-filter="*" style="width: 30%; margin: 0 auto; margin-bottom: 5px"><img width="100%" src="images/logo.webp" alt=""></button>
                            <center><br>
                                <button data-filter=".gal_a"><img width="100%" src="images/clubePriveAzul.webp" alt=""></button>
                                <button data-filter=".gal_b"><img width="100%" src="images/waterpark.webp" alt=""></button>
                                <button data-filter=".gal_c"><img width="100%" src="images/nautico.webp" alt=""></button>
                    </div>
                </div>
            </div>
            <div class="gallery-list row">
                <?php
                $busca_atracao_prive = 'SELECT * FROM atracoes WHERE id_parque = 1 AND status = 1 ORDER BY ordem';
                $query_atracao_prive = $connect->query($busca_atracao_prive);
                $count = 1;
                while ($result = $query_atracao_prive->fetch_assoc()) {
                ?>
                    <div class="col-md-4 col-sm-6 gallery-grid gal_a" style="padding: 5px;">
                        <div class="gallery-single fix">
                            <img src="../assets/img/<?php echo $result['url_img']; ?>" class="img-fluid" alt="Image">
                            <div class="img-overlay">
                                <a href="../assets/img/<?php echo $result['url_img']; ?>" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
                            </div>
                        </div>
                    </div>
                <?php } ?>

                <?php
                $busca_atracao_prive = 'SELECT * FROM atracoes WHERE id_parque = 2 AND status = 1 ORDER BY ordem';
                $query_atracao_prive = $connect->query($busca_atracao_prive);
                $count = 1;
                while ($result = $query_atracao_prive->fetch_assoc()) {
                ?>
                    <div class="col-md-4 col-sm-6 gallery-grid gal_b" style="padding: 5px;">
                        <div class="gallery-single fix">
                            <img src="../assets/img/<?php echo $result['url_img']; ?>" class="img-fluid" alt="Image">
                            <div class="img-overlay">
                                <a href="../assets/img/<?php echo $result['url_img']; ?>" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
                            </div>
                        </div>
                    </div>
                <?php } ?>

                <?php
                $busca_atracao_prive = 'SELECT * FROM atracoes WHERE id_parque = 3 AND status = 1 ORDER BY ordem';
                $query_atracao_prive = $connect->query($busca_atracao_prive);
                $count = 1;
                while ($result = $query_atracao_prive->fetch_assoc()) {
                ?>
                    <div class="col-md-4 col-sm-6 gallery-grid gal_c" style="padding: 5px;">
                        <div class="gallery-single fix">
                            <img src="../assets/img/<?php echo $result['url_img']; ?>" class="img-fluid" alt="Image">
                            <div class="img-overlay">
                                <a href="../assets/img/<?php echo $result['url_img']; ?>" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <!-- end section -->

    <!-- Footer -->
    <footer id="contato" style="padding: 30px; position: relative; z-index: 99999; background-color: #fff; border-top: solid #f68c16 5px">
        <div class="row">
            <div class="col-3" style="padding: 0%">
                <?php
                $buscar_rodape = 'SELECT * FROM rodape LIMIT 1';
                $query_rodape = $connect->query($buscar_rodape);
                if ($query_rodape != false) {
                    $result = $query_rodape->fetch_assoc();
                    if (count($result) != 0) {
                ?>
                        <img loading="lazy" class="logo-footer" src="../assets/img/<?php echo $result["url_img_logo"]; ?>" alt="Logo Privediversão">
            </div>
            <div class="col-9" style="padding: 0%">
                <div class="row text-footer" style="padding: 0%">
                    <div class="col-12" style="padding: 0%">
                    </div>
                    <div class="col-12 text-info">
                        <center>
                            <p>
                                <svg style="max-width: 10px;" fill="#4c4c73" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" alt="Logo facebook">
                                    <!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
                                    <path d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z" />
                                </svg>
                                <?php echo $result["telefone"] ?>
                            </p>
                            <p>
                                <svg style="max-width: 10px;" fill="#4c4c73" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" alt="Logo facebook">
                                    <!--! Font Awesome Pro 6.2.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
                                    <path d="M64 112c-8.8 0-16 7.2-16 16v22.1L220.5 291.7c20.7 17 50.4 17 71.1 0L464 150.1V128c0-8.8-7.2-16-16-16H64zM48 212.2V384c0 8.8 7.2 16 16 16H448c8.8 0 16-7.2 16-16V212.2L322 328.8c-38.4 31.5-93.7 31.5-132 0L48 212.2zM0 128C0 92.7 28.7 64 64 64H448c35.3 0 64 28.7 64 64V384c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128z" />
                                </svg>
                                <?php echo $result["email"] ?>
                            </p>
                            <p>
                                <?php echo $result["text_info"] ?>
                            </p>
                            <h6 class="copyright">&#169;Todos os direitos reservados. Privé Diversão 2022</h6>
                        </center>
                    </div>
                </div>
            </div>
    <?php }
                } ?>
        </div>
    </footer>
    <!-- End Footer -->

    <!-- Botão flutuante WhatsApp -->
    <a href="https://api.whatsapp.com/send?phone=556434548400" title="link para conversar com suporte pelo WhatsApp"><img loading="lazy" class="btn-whatsapp" src="../assets/img/whatsapp-logo.webp" alt="Ícone do WhatsApp"></a>
    <!-- End flutuante WhatsApp -->

    <!-- WEB CHAT -->
    <script>
        window.renderBotWidget(
            '639094e3a4425e0019058704'
        );
    </script>

    <!-- MODAL CONFIRMAR O E-MAIL -->
    <div class="modal" aria-labelledby="exampleModalLabel" tabindex="-1" id="modal" aria-modal="hidden">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirmação do e-mail</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" onclick="$('#modal').hide();" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p style="color: black; text-align: center;">
                        <?php if (isset($_GET["confirmar"])) {
                            $email = $_GET["confirmar"];
                            echo "Por favor, verifique seu e-mail clicando no link que enviamos para $email. Caso não escontre, verifique a caixa de spam.";
                        } else if (isset($_GET["confirmado"])) {
                            echo "Muito obrigado, e-mail verificado com sucesso!";
                        } ?>
                        <br>
                        <img style="max-width: 40%; margin: 0 auto;" src="../assets/img/email.png" alt="">
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" style="background-color: green; border: solid green 1px;" onclick="$('#modal').hide();" class="btn btn-primary" data-bs-dismiss="modal">Ok</button>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL CONFIRMAR O E-MAIL -->

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- Camera Slider -->
    <script src="js/jquery.mobile.customized.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/parallaxie.js"></script>
    <script src="js/headline.js"></script>
    <!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/jquery.vide.js"></script>

</body>

</html>