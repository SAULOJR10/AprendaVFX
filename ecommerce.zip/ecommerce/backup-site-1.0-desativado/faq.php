<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="pt">
<!--<![endif]-->

<head>
    <!-- Primary Meta Tags -->
    <title>Parques em Caldas Novas | Privé Diversão | Site Oficial</title>
    <meta name="title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
    <meta name="description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://metatags.io/">
    <meta property="og:title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
    <meta property="og:description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
    <meta property="og:image" content="https://metatags.io/assets/meta-tags-16a33a6a8531e519cc0936fbba0ad904e52d35f34a46c97a2c9f6f7dd7d336f2.png">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://metatags.io/">
    <meta property="twitter:title" content="Parques em Caldas Novas | Privé Diversão | Site Oficial">
    <meta property="twitter:description" content="Piscina de ondas, toboágua, lazy river, piscinas infantis, recreação, e muito mais. Hospede-se nos hotéis do Privé e ganhe Transfer Exclusivo hotel-parque-hotel. Parque Aquático em Caldas. Recreação.">
    <meta property="twitter:image" content="https://metatags.io/assets/meta-tags-16a33a6a8531e519cc0936fbba0ad904e52d35f34a46c97a2c9f6f7dd7d336f2.png">

    <!--- basic page needs
   ================================================== -->
    <meta charset="utf-8">
    <meta name="description" content="Separamos aqui as dúvidas mais frequentes de nossos visitantes em relação, compra de ingresso (físico ou virtual) e dúvidas gerais quanto a nossos parques (regras, horários, vantagens entre outros)">
    <meta name="keywords" content="parques, aquático, diversão, Caldas Novas, parque aquático, parque de diversão, water park, nautico, prive, clube, resort">
    <meta name="author" content="SAULO COELHO DA COSTA JUNIOR +55 (64) 99300-7836">
    <meta name="robots" content="index, follow">
    <meta name="canonical" content="https://privediversao.com.br">
    <meta name="sitemap" type="application/xml" href="./sitemap.xml">

    <!-- mobile specific metas
   ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- favicons
	================================================== -->
    <link rel="shortcut icon" href="assets/img/favicon.webp">

    <!-- CSS
   ================================================== -->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- script
   ================================================== -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>

    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-5D93CSS');
    </script>

    <script type="text/javascript">
        var analyticsFileTypes = [''];
        var analyticsSnippet = 'enabled';
        var analyticsEventTracking = 'enabled';
    </script>
    <script type="text/javascript">
        var _gaq = _gaq || [];

        _gaq.push(['_setAccount', 'UA-114439357-1']);
        _gaq.push(['_addDevId', 'i9k95']); // Google Analyticator App ID with Google
        _gaq.push(['_trackPageview']);

        (function() {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>


</head>

<body>
    <!-- Menu laterela -->
    <div class="side_menu">
        <div class="burger_box">
            <div class="menu-icon-container">
                <a href="#" class="menu-icon js-menu_toggle closed">
                    <span class="menu-icon_box">
                        <span class="menu-icon_line menu-icon_line--1" style="height: 2px;"></span>
                        <span class="menu-icon_line menu-icon_line--2"></span>
                        <span class="menu-icon_line menu-icon_line--3"></span>
                    </span>
                </a>
            </div>
            <a href="https://www.facebook.com/privediversao">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z" />
                </svg>
            </a>
            <a href="https://www.instagram.com/privediversao/">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z" />
                </svg>
            </a>
            <a href="https://www.youtube.com/user/rededehoteisprive">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                    <path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z" />
                </svg>
            </a>
            <a href="https://www.tripadvisor.com.br/Search?geo=1012170&pid=3826&typeaheadRedirect=true&redirect=&startTime=1482514871259&uiOrigin=MASTHEAD&q=prive%20nautico%20water%20park&returnTo=http%253A__2F____2F__www__2E__tripadvisor__2E__com__2E__br__2F__&searchSessionId=DD87D6CD0E1E10320CA24123E1055CA01482514861433ssid#&ssrc=A&dist=5km&o=0&sid=6DC9E017DB034A749E75E5B7DBC1EEBC1668687013976&blockRedirect=true">
                <img loading="lazy" src="assets/img/tripadvisor-logo.webp">
            </a>
            <a href="https://br.linkedin.com/company/grupoprive">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z" />
                </svg>
            </a>
        </div>
        <div class="px-5">
            <img loading="lazy" class="list_item" src="assets/img/logo.webp" style="max-width: 40%; margin: 0 auto;">
            <hr style="color: #f68c16; background-color: #f68c16; height: 3px;">
            <ul class="list_load">
                <li class="list_item"><a href="index.php">Home</a></li>
                <li class="list_item"><a href="index.php#atracoes">Parques</a></li>
                <li class="list_item"><a href="https://privehoteiseparques.com.br/">Onde Ficar</a></li>
                <li class="list_item"><a href="index.php#promocao">Promoções</a></li>
                <li class="list_item"><a href="index.php#localizacao">Como Chegar</a></li>
                <li class="list_item"><a href="https://wam.group/politica-de-privacidade/">Política de Privacidade</a></li>
                <li class="list_item"><a href="#">FAQ</a></li>
            </ul>
            <div class="spacer_box">
                <p>WAM BRASIL</p>
            </div>
        </div>
    </div>
    <!-- End menu lateral -->

    <!-- Menu superior -->
    <div class="menu-top">
        <center><a href="#"><img loading="lazy" class="logo" src="assets/img/logo-navbar.webp" alt=""></a></center>
    </div>
    <!-- End menu superior -->
    <!-- FAQ'S -->
    <center style="margin-top: 100px;">
        <button class="buttons_faq" onclick="open_questions('gerais')" id="button_gerais" style="color: #000; text-decoration: underline;">Duvidas gerais</button>
        <button class="buttons_faq" onclick="open_questions('internet')" id="button_internet">Duvidas pelo site</button>
    </center>
    <div class="content">
        <section class="faqs_gerais" id="faq_gerais">
            <div class="container container-faq">
                <div class="accordion">
                    <div>
                        <div class="accordion-item" id="question1">
                            <a class="accordion-link" id="link_1" onclick="open_answer(1)" href="#question1">
                                <div class="flex">
                                    <img src="assets/img/down-solid.svg" id="seta_1" class="icon-more" alt="">
                                    <h3>É permitido a entrada de alimentos e bebidas nos Parques?</h3>
                                </div>
                            </a>
                            <div class="answer">
                                <p> Não, pois visando a segurança de nossos visitantes a entrada de alimentos e bebidas no parque é restrita e controlada. Devido estarmos localizados em uma região de clima quente, há métodos especiais para conservação dos alimentos, para evitar intoxicações.<br>
                                    Os nossos produtos comercializados dentro dos parques são armazenados de forma correta para garantir a qualidade do que é consumido pelos nossos visitantes. Lembramos que a entrada com mamadeiras e papinhas infantis são permitidas. <br>
                                    Em casos de restrição alimentar, a entrada com alimentos especiais é permitida, mediante a apresentação de laudo médico diretamente na portaria do Parque.</p>
                            </div>
                        </div>
                        <div class="accordion-item" id="question2">
                            <a class="accordion-link" id="link_2" onclick="open_answer(2)" href="#question2">
                                <div class="flex">
                                    <img src="assets/img/down-solid.svg" id="seta_2" class="icon-more" alt="">
                                    <h3>Qual o horário de funcionamento dos Parques?</h3>
                                </div>
                            </a>
                            <div class="answer">
                                <p> <b style="font-weight: 900;">Durante a semana:</b><br>
                                    Clube Privé – 10h às 17h (fechado segunda, terça e quarta para manutenção)<br>
                                    Water Park – 10h às 17h (fechado quinta-feira para manutenção)<br>
                                    Náutico Praia Clube – 10h às 17h (fechado segunda para manutenção)<br><br>

                                    <b style="font-weight: 900;">Finais de semana e feriados:</b><br>

                                    Clube Privé – 09h às 17h <br>
                                    Water Park – 09h às 17h <br>
                                    Náutico Praia Clube – 09h às 17h <br><br>

                                    Os horários e dias de funcionamento dos parques podem ser alterados durante o período de férias e feriados. Por favor, entre em contato com o Atendimento Privé Diversão (64) 3454-8400 para mais informações.
                                </p>
                            </div>
                        </div>
                        <div class="accordion-item" id="question3">
                            <a class="accordion-link" id="link_3" onclick="open_answer(3)" href="#question3">
                                <div class="flex">
                                    <img src="assets/img/down-solid.svg" id="seta_3" class="icon-more" alt="">
                                    <h3>O ingresso Day User permite a saída e retorno ao Parque?</h3>
                                </div>
                            </a>
                            <div class="answer">
                                <p> Não. O ingresso Day User permite 1 (um) único acesso ao Parque, não sendo possível sair e retornar.</p>
                            </div>
                        </div>
                        <div class="accordion-item" id="question4">
                            <a class="accordion-link" id="link_4" onclick="open_answer(4)" href="#question4">
                                <div class="flex">
                                    <img src="assets/img/down-solid.svg" id="seta_4" class="icon-more" alt="">
                                    <h3>Quais os ingressos que possuem descontos?</h3>
                                </div>
                            </a>
                            <div class="answer">
                                <p> Atualmente o Privé Diversão possuí desconto em ingressos para: Estudantes, idosos (acima de 60 anos) e crianças (8 a 12 anos).<br>
                                    Professores possuem desconto no Water Park e Clube Prive (não válido para o Náutico Praia Clube) – mediante a apresentação do último contracheque que comprove a profissão.<br>
                                    Ingressos para Estudantes – venda exclusiva na bilheteria dos parques, mediante a apresentação de carteirinha de estudante.<br>
                                    Idosos (acima de 60 anos) e Crianças (08 a 12 anos) – Vendas no site, loja oficial, pontos de vendas autorizados e bilheteria, sendo obrigatória a comprovação de idade na entrada do parque.<br>
                                    Crianças até 7 anos é FREE, se acompanhada de um adulto pagante e mediante a apresentação de documento comprobatório.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="faqs_internet" id="faq_internet">
            <div class="container">
                <div class="accordion">
                    <div class="accordion-item" id="question5">
                        <a class="accordion-link" id="link_5" onclick="open_answer(5)" href="#question5">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_5" class="icon-more" alt="">
                                <h3>Comprei ingresso(s) na Internet para outra pessoa, mas o cadastro está no meu nome.<br> Ele poderá retirar o(s) ingresso(s) sem minha presença?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p> Não, para retirar os ingressos o mesmo deverá ser assinado presencialmente pelo títular da compra no ato da apresentação no guichê do referido parque, portando o cartão que fez a compra e cópia do documento original com foto.</p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question6">
                        <a class="accordion-link" id="link_6" onclick="open_answer(6)" href="#question6">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_6" class="icon-more" alt="">
                                <h3>O Privé Diversão oferece desconto na compra de muitos ingressos?<br>Quero organizar uma excursão. Teria alguma vantagem?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p> Ingressos para grupos com mais de 15 pessoas, podem ser adquiridos com condições especiais exclusivamente na loja oficial do Privé Diversão, para mais informações entre em contato (64) 3455-4040.</p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question7">
                        <a class="accordion-link" id="link_7" onclick="open_answer(7)" href="#question7">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_7" class="icon-more" alt="">
                                <h3>Os ingressos on-line incluem algum tipo de serviço ou alimentação ?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p> Os ingressos adquiridos no site permite o acesso ao parque escolhido (por uma única vez) no horário operacional e direito à utilização das atrações. Com exceção de alimentação, estacionamento, produtos da loja, aluguéis de boias, guarda-volumes, armários, atrações pagas à parte, atrações em teste e/ou em manutenção. Em determinados períodos são disponibilizados no site (e-Commerce) ingressos promocionais com almoço incluso, somente nestes casos o comprador terá direito a alimentação. O benefício é identificado no voucher na bilheteria dos parques.</p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question8">
                        <a class="accordion-link" id="link_8" onclick="open_answer(8)" href="#question8">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_8" class="icon-more" alt="">
                                <h3>Comprei meu(s) ingresso(s), mas não consegui utilizá-lo(s) antes da validade.<br>Como faço para revalidá-lo(s) ?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p> Para avaliar a possibilidade de prorrogação da data de validade da utilização do ingresso, é necessário entrar em contato através do e-mail atendimentoprivediversao@grupoprive.com.br, escrever no assunto do e-mail “Prorrogação de Validade Privé Diversão”.<br>
                                O prazo máximo para solicitação é de 2 dias antes do vencimento.<br>
                                Não é possível prorrogação por mais de uma vez.<br>
                                Não é possível fazer a devolução de valores após o vencimento.<br>
                                O ingresso uma vez prorrogado, tem um prazo máximo de até 60 dias para utilização.<br>
                                Não é possível alterar o parque escolhido anteriormente e a quantidade de ingressos.</p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question9">
                        <a class="accordion-link" id="link_9" onclick="open_answer(9)" href="#question9">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_9" class="icon-more" alt="">
                                <h3>Não poderei ir ao Parque no dia escolhido, posso reagendar meu(s) ingresso(s) ?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p>O reagendamento de ingressos pode ser feito até em 2 dias úteis antes da data escolhida para o uso. Para reagendar é necessário entrar em contato através do e-mail atendimentoprivediversao@grupoprive.com.br, escrever no assunto do e-mail “Reagendamento de Visita Privé Diversão”.</p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question10">
                        <a class="accordion-link" id="link_10" onclick="open_answer(10)" href="#question10">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_10" class="icon-more" alt="">
                                <h3>Não irei mais ao parque, posso cancelar meu(s) ingresso(s) ?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p> A solicitação para cancelamento do ingresso deverá ocorrer no prazo de 7 (sete) dias após a efetivação da compra, sendo que após este período, haverá a retenção de 20% sobre o valor da compra efetivada. Para solicitar o cancelamento o comprador deve enviar um e-mail para atendimentoprivediversao@grupoprive.com.br , escrever no assunto do e-mail “Cancelamento de Ingresso Privé Diversão”, informando o motivo do cancelamento, para que sejam feitos os procedimentos obrigatórios de cancelamento de compra. O período para estorno de valores é de 15 dias úteis, a contar da data de envio do formulário preenchido.</p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question11">
                        <a class="accordion-link" id="link_11" onclick="open_answer(11)" href="#question11">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_11" class="icon-more" alt="">
                                <h3>Como faço para retirar os ingressos que comprei pela Internet?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p> Após a compra no site do Privé Diversão, o pagamento será processado e autorizado. Após essa autorização o voucher é encaminhado para o e-mail cadastrado.<br>
                                Caso não receba o voucher, verifique a caixa de spam do e-mail ou entre em contato com o Atendimento Privé Diversão através do (64) 3454-8400.</p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question12">
                        <a class="accordion-link" id="link_12" onclick="open_answer(12)" href="#question12">
                            <div class="flex">
                                <img src="assets/img/down-solid.svg" id="seta_12" class="icon-more" alt="">
                                <h3>A compra pelo site Privé Diversão pode ser parcelada?</h3>
                            </div>
                        </a>
                        <div class="answer">
                            <p> Sim, compras a partir de R$100,00 podem ser parceladas, com parcela mínima de R$ 50,00. Parcelamento em até 3X sem juros.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- END FAQ'S -->

    <!-- Botão futuante "compre seu ingresso" -->
    <a href="https://privediversao.com.br/loja/">
        <div class="ingresso">
            <p>Compre seu ingresso agora! <img loading="lazy" class="icon-dedo" src="assets/img/dedo.webp"></p>
        </div>
    </a>
    <!-- End futuante "compre seu ingresso" -->

    <!-- Botão futuante WhatsApp -->
    <a href="https://api.whatsapp.com/send?phone=556434548400"><img loading="lazy" class="btn-whatsapp" src="assets/img/whatsapp-logo.webp"></a>
    <!-- End futuante WhatsApp -->
</body>

</html>