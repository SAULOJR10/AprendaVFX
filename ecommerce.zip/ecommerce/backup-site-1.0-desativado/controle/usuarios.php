<?php
require_once "../assets/bib/conexao.php";

if (!isset($_SESSION)) session_start();

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID'])) {
    // Destrói a sessão por segurança
    session_destroy();
    // Redireciona o visitante de volta pro login
    header("Location: login.php");
    exit;
}
if ($_SESSION["UsuarioNivel"] != "adm") {
    $retorno = explode('?', $_SERVER['HTTP_REFERER'])[0];
    header("Location: $retorno");
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- ----------Importa head---------- -->
    <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
    <!-- Importa menus lateral e superior -->
    <?php if ($_SESSION["UsuarioNivel"] == "cl") {
        require_once "menus.php";
    } else {
        require_once "menus_adm.php";
    }
    ?>
    <!-- -------------------------------- -->

    <div class="content-controle">
        <div class="card">
            <div class="text">
                <h4>Usuários</h4>
                <?php if (!isset($_GET['id'])) { ?>
                    <form action="assets/functions/insert.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="usuario" style="display: none;" required="">
                        <label>Nome:
                            <input class="title" type="text" name="nome" placeholder="Nome" required="">
                        </label>
                        <label class="metade">CPF:
                            <input class="cpf" type="text" name="cpf" placeholder="CPF" required="">
                        </label>
                        <label class="metade">Cep:
                            <input class="cep" type="text" name="cep" placeholder="xxxxx-xxx" required="">
                        </label>
                        <label class="metade">Telefone:
                            <input class="telefone" type="text" name="telefone" placeholder="WhatsApp" required="">
                        </label>
                        <label class="metade">Nascimento:
                            <input class="data" type="text" name="nascimento" placeholder="data" required="">
                        </label>
                        <label>E-mail:
                            <input class="email" type="text" name="email" placeholder="@gmail.com" required="">
                        </label>
                        <label class="metade">Login:
                            <input class="user" type="text" name="login" placeholder="Login" required="">
                        </label>
                        <label class="metade">Nível:
                            <select name="nivel" required="">
                                <option value="">Selecione</option>
                                <option value="adm">Administrador</option>
                                <option value="cl">Colaborador</option>
                            </select>
                        </label>
                        <label>Senha:
                            <input class="senha" type="password" name="senha" placeholder="mínimo 8 caracteres">
                        </label>
                        <label>Confirmar senha:
                            <input class="senha" type="password" name="confirmar" placeholder="Digite novamente">
                        </label>
                        <button type="submit" class="enviar">Enviar</button>
                    </form>
                <?php } else if ($_GET['id'] != '') {
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM usuario INNER JOIN login ON usuario.id_login = login.id WHERE usuario.id = $id LIMIT 1";
                    $query_slide = $connect->query($sql);
                    $resultado = $query_slide->fetch_assoc();
                ?>
                    <form action="assets/functions/update.php" method="post" enctype="multipart/form-data">
                    <input type="text" name="acao" value="usuario" style="display: none;" required="">
                    <input type="text" name="id" value="<?php echo $resultado["id_login"]?>" style="display: none;" required="">
                        <label>Nome:
                            <input class="title" type="text" value="<?php echo $resultado['nome'];?>" name="nome" placeholder="Nome" required="">
                        </label>
                        <label class="metade">CPF:
                            <input class="cpf" type="text" name="cpf" value="<?php echo $resultado['cpf'];?>" placeholder="CPF" required="">
                        </label>
                        <label class="metade">Cep:
                            <input class="cep" type="text" name="cep" value="<?php echo $resultado['cep'];?>" placeholder="xxxxx-xxx" required="">
                        </label>
                        <label class="metade">Telefone:
                            <input class="telefone" type="text" name="telefone" value="<?php echo $resultado['telefone'];?>" placeholder="WhatsApp" required="">
                        </label>
                        <label class="metade">Nascimento:
                            <input class="data" type="text" name="nascimento" value="<?php echo $resultado['data_nascimento'];?>" placeholder="data" required="">
                        </label>
                        <label>E-mail:
                            <input class="email" type="text" name="email" value="<?php echo $resultado['email'];?>" placeholder="@gmail.com" required="">
                        </label>
                        <label class="metade">Login:
                            <input class="user" type="text" name="login" value="<?php echo $resultado['login'];?>" placeholder="Login" required="">
                        </label>
                        <label class="metade">Nível:
                            <select name="nivel" required="">
                                <option value="">Selecione</option>
                                <option value="adm" <?php if($resultado['nivel'] == "adm"){?> selected <?php }?>>Administrador</option>
                                <option value="cl" <?php if($resultado['nivel'] == "cl"){?> selected <?php }?>>Colaborador</option>
                            </select>
                        </label>
                        <button type="submit" style="background-color: #0c0;" class="enviar">Atualizar</button>
                    </form>
                <?php } ?>
            </div>
        </div>
        <div class="card" style="width: 99%; margin-top: 20px; padding: 40px 5px;">
            <h4>Atrações Cadastradas</h4>
            <hr>
            <div class="text">
                <table>
                    <tbody>
                        <tr>
                            <th>Id</th>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>Telefone</th>
                            <th>Email</th>
                            <th>Editar</th>
                            <th>Ativar / Desativar</th>
                            <th>Excluir</th>
                        </tr>
                        <?php
                        $busca_slide = 'SELECT * FROM usuario INNER JOIN login ON usuario.id_login = login.id';
                        $query_slide = $connect->query($busca_slide);
                        $count = 1;
                        while ($result = $query_slide->fetch_assoc()) {
                            $id = $result['id_login'];
                            $nome = $result['nome'];
                            $cpf = $result['cpf'];
                            $telefone = $result['telefone'];
                            $email = $result['email'];
                            $status = $result['status'];
                            $tabela = "<tr>
                                        <td>$id</td>
                                        <td>$nome</td>
                                        <td>$cpf</td>
                                        <td>$telefone</td>
                                        <td>$email</td>
                                        <td><a href='usuarios.php?id=$id'><img src='../assets/img/edit.svg' style='max-width: 20px;'></a></td>";
                            if ($status == 1) {
                                $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='desativa' name='acao' style='display: none;'>
                                                <input type='text' value='login' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/ativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                            } else {
                                $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='ativa' name='acao' style='display: none;'>
                                                <input type='text' value='login' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/desativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                            }
                            $tabela .= "<td>
                                            <form action='assets/functions/delete.php' id='form$id'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='exclui_login' name='acao' style='display: none;'>
                                                <button type='button' onclick='confirmar($id)' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/lixo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";
                            echo $tabela;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
    if (isset($_GET["sucesso"])) {
        echo "<script>alert('Sucesso!!!')</script>";
    } else if (isset($_GET["erro"])) {
        $erro = $_GET["erro"];
        echo "<script>alert('$erro')</script>";
    }
    ?>
</body>

</html>