<?php
require_once "../assets/bib/conexao.php";

if (!isset($_SESSION)) session_start();

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID'])) {
    // Destrói a sessão por segurança
    session_destroy();
    // Redireciona o visitante de volta pro login
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- ----------Importa head---------- -->
    <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
    <!-- Importa menus lateral e superior -->
    <?php if ($_SESSION["UsuarioNivel"] == "cl") {
        require_once "menus.php";
    } else {
        require_once "menus_adm.php";
    }
    ?>

    <div class="content-controle">
        <div class="card">
            <div class="text">
                <h4>Slide Home Pc</h4>
                <p class="informacao">o que estou editando?</p>
                <?php if (!isset($_GET['id'])) { ?>
                    <form action="assets/functions/insert.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="slide_pc" style="display: none;" required="">
                        <label>Imagem:
                            <label class="label_file"><span id="value_file">Resolução (1200x 628y)</span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img" required="">
                            </label>
                        </label>
                        <label>Descrição:
                            <input class="see" type="text" name="desc" placeholder="Para deficientes visuais" required="">
                        </label>
                        <label>Ordem:
                            <input class="order" type="number" name="order" placeholder="ordem de exibição" required="">
                        </label>
                        <label>Status:
                            <select name="status" required="">
                                <option value="">Selecione</option>
                                <option value="1">Ativado</option>
                                <option value="2">Desativado</option>
                            </select>
                        </label>
                        <button type="submit" class="enviar">Enviar</button>
                    </form>
                <?php } else if ($_GET['id'] != '') {
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM slide_home_pc WHERE id = $id LIMIT 1";
                    $query_slide = $connect->query($sql);
                    $resultado = $query_slide->fetch_assoc();
                ?>
                    <form action="assets/functions/update.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="slide_pc" style="display: none;" required="">
                        <input type="text" name="id" value="<?php echo $_GET['id']; ?>" style="display: none;" required="">
                        <label>Imagem:
                            <input style="display: none;" value="<?php echo $resultado['url_img']; ?>" type="text" name="img_text" required="">
                            <label class="label_file"><span id="value_file"><?php echo $resultado['url_img']; ?></span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img" required="">
                            </label>
                        </label>
                        <label>Descrição:
                            <input class="see" value="<?php echo $resultado['descricao']; ?>" type="text" name="desc" placeholder="Para deficientes visuais" required="">
                        </label>
                        <label>Ordem:
                            <input class="order" value="<?php echo $resultado['ordem']; ?>" type="number" name="order" placeholder="ordem de exibição" required="">
                        </label>
                        <label>Status:
                            <select name="status" required="">
                                <option value="">Selecione</option>
                                <option value="1" <?php if ($resultado['status'] == 1) { ?> selected <?php } ?>>Ativado</option>
                                <option value="2" <?php if ($resultado['status'] == 2) { ?> selected <?php } ?>>Desativado</option>
                            </select>
                        </label>
                        <button type="submit" style="background-color: #0c0;" class="enviar">Atualizar</button>
                    </form>
                <?php } ?>
            </div>
        </div>
        <div class="card" style="width: 99%; margin-top: 20px; padding: 40px 5px;">
            <h4>Slides Cadastrados</h4>
            <hr>
            <div class="text">
                <table>
                    <tbody>
                        <tr>
                            <th>Id</th>
                            <th>Imagem</th>
                            <th>Descrição</th>
                            <th>Ordem</th>
                            <th>Editar</th>
                            <th>Ativar / Desativar</th>
                            <th>Excluir</th>
                        </tr>
                        <?php $busca_slide = 'SELECT * FROM slide_home_pc ORDER BY ordem, status';
                        $query_slide = $connect->query($busca_slide);
                        $count = 1;
                        $tabela = "";
                        while ($result = $query_slide->fetch_assoc()) {
                            $id = $result['id'];
                            $img = $result['url_img'];
                            $descricao = $result['descricao'];
                            $ordem = $result['ordem'];
                            $status = $result['status'];
                            $tabela .= "
                                    <tr>
                                        <td>$id</td>
                                        <td><img src='../assets/img/$img' style='max-width: 120px;'></td>
                                        <td>$descricao</td>
                                        <td>$ordem</td>
                                        <td><a href='slide-pc.php?id=$id'><img src='../assets/img/edit.svg' style='max-width: 20px;'></a></td>";
                            if ($status == 1) {
                                $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='desativa' name='acao' style='display: none;'>
                                                <input type='text' value='slide_home_pc' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/ativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                            } else {
                                $tabela .= "<td>
                                        <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                            <input type='text' value='$id' name='id' style='display: none;'>
                                            <input type='text' value='ativa' name='acao' style='display: none;'>
                                            <input type='text' value='slide_home_pc' name='tabela' style='display: none;'>
                                            <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                <img src='../assets/img/desativa.svg' style='max-width: 20px;'>
                                            </button>
                                        </form>
                                    </td>";
                            }
                            $tabela .= "<td>
                                            <form action='assets/functions/delete.php' id='form$id'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='exclui' name='acao' style='display: none;'>
                                                <input type='text' value='slide_home_pc' name='tabela' style='display: none;'>
                                                <button type='button' onclick='confirmar($id)' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/lixo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";
                        }
                        echo $tabela;
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php
    if (isset($_GET["sucesso"])) {
        echo "<script>alert('Sucesso!!!')</script>";
    } else if (isset($_GET["erro"])) {
        echo "<script>alert('Alguma coisa deu errado, tente novamente mais tarde.')</script>";
    }
    ?>
</body>

</html>