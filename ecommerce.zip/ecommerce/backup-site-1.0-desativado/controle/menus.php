    <!-- Menu superior -->
    <div class="menu-top">
        <center><a href="#"><img loading="lazy" class="logo" src="../assets/img/logo-navbar.webp" alt=""></a></center>
    </div>
    <!-- End menu superior -->
    <!-- Menu lateral -->
    <div class="side_menu">
        <div class="burger_box">
            <div class="menu-icon-container">
                <a href="#" class="menu-icon js-menu_toggle closed">
                    <span class="menu-icon_box">
                        <span class="menu-icon_line menu-icon_line--1" style="height: 2px;"></span>
                        <span class="menu-icon_line menu-icon_line--2"></span>
                        <span class="menu-icon_line menu-icon_line--3"></span>
                    </span>
                </a>
            </div>
        </div>
        <div class="px-5">
            <img loading="lazy" class="list_item" src="../assets/img/logo.webp" style="max-width: 40%; margin: 0 auto;">
            <hr style="color: #f68c16; background-color: #f68c16; height: 3px;">
            <ul class="list_load">
                <li class="list_item"><a href="index.php">Início</a></li>
                <li class="list_item"><a href="slide-mobile.php">Slide Home Mobile</a></li>
                <li class="list_item"><a href="slide-pc.php">Slide Home Pc</a></li>
                <li class="list_item"><a href="atracoes.php">Atrações</a></li>
                <li class="list_item"><a href="promocao.php">Promoção</a></li>
                <li class="list_item"><a href="faqs.php">Perguntas Frequentes</a></li>
                <li class="list_item"><a href="rodape.php">Rodapé</a></li>
                <li class="list_item"><a href="login.php?sair=">sair</a></li>
            </ul>
            <div class="spacer_box">
                <p>WAM HOTEIS E PARQUES</p>
            </div>
        </div>
    </div>
    <!-- End menu lateral -->