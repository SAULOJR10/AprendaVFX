<!--- basic page needs
   ================================================== -->
<meta charset="utf-8">
<title>Painel de Controle</title>
<meta name="description" content="">
<meta name="author" content="SAULO COELHO DA COSTA JUNIOR +55 (64) 99300-7836">

<!-- mobile specific metas
   ================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- favicons
	================================================== -->
<link rel="shortcut icon" href="../assets/img/favicon.webp">

<!-- CSS
   ================================================== -->
<link rel="stylesheet" href="../assets/css/bootstrap.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="assets/css/style.css">

<!-- script
   ================================================== -->
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/custom.js"></script>
<script src="assets/js/custom.js"></script>