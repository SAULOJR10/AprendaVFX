<?php
    if (!isset($_SESSION)) session_start();

    // Verifica se não há a variável da sessão que identifica o usuário
    if (!isset($_SESSION['UsuarioID'])) {
        // Destrói a sessão por segurança
        session_destroy();
        // Redireciona o visitante de volta pro login
        header("Location: login.php"); exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <!-- ----------Importa head---------- -->
   <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
   <!-- Importa menus lateral e superior -->
   <?php if ($_SESSION["UsuarioNivel"] == "cl") {
        require_once "menus.php";
    } else {
        require_once "menus_adm.php";
    }
    ?>
    <!-- -------------------------------- -->

   <div class="content-controle">
      <div class="card">
         <div class="text">
            <h4 style="font-size: 18px;">Bem vindo ao painel de controle! Aqui você poderá alterar e personalizar seu site.<br><br>
                Acesse o menu a esquerda para começar!   
            </h4>
         </div>
      </div>
   </div>
   <?php
    if (isset($_GET["sucesso"])) {
        echo "<script>alert('Sucesso!!!')</script>";
    } else if (isset($_GET["erro"])) {
        echo "<script>alert('Alguma coisa deu errado, tente novamente mais tarde.')</script>";
    }
    ?>
</body>

</html>