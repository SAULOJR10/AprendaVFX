<?php
require_once "../assets/bib/conexao.php";

if (!isset($_SESSION)) session_start();

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID'])) {
    // Destrói a sessão por segurança
    session_destroy();
    // Redireciona o visitante de volta pro login
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- ----------Importa head---------- -->
    <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
    <!-- Importa menus lateral e superior -->
    <?php if ($_SESSION["UsuarioNivel"] == "cl") {
        require_once "menus.php";
    } else {
        require_once "menus_adm.php";
    }
    ?>

    <div class="content-controle">
        <div class="card">
            <div class="text">
                <h4>Rodapé</h4>
                <p class="informacao">o que estou editando?</p>
                <?php if (!isset($_GET['id'])) { ?>
                    <form action="assets/functions/insert.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="rodape" style="display: none;" required="">
                        <label>Imagem (logo):
                            <label class="label_file"><span id="value_file">Enviar Arquivo</span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img" required="">
                            </label>
                        </label>
                        <label>Informações da Empresa:
                            <input class="information" type="text" name="info" placeholder='Pular linha: "<br>"' required="">
                        </label>
                        <label>Email:
                            <input class="email" type="text" name="email" placeholder="@gmail.com" required="">
                        </label>
                        <label>Telefone:
                            <input class="telefone" type="text" name="telefone" placeholder="(xx) xxxx-xxxx" required="">
                        </label>
                        <button type="submit" class="enviar">Enviar</button>
                    </form>
                <?php } else if ($_GET['id'] != '') {
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM rodape WHERE id = $id LIMIT 1";
                    $query_slide = $connect->query($sql);
                    $resultado = $query_slide->fetch_assoc();
                ?>
                    <form action="assets/functions/update.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="rodape" style="display: none;" required="">
                        <input type="text" name="id" value="<?php echo $_GET['id']; ?>" style="display: none;" required="">
                        <label>Imagem (logo):
                            <input style="display: none;" value="<?php echo $resultado['url_img_logo']; ?>" type="text" name="img_text" required="">
                            <label class="label_file"><span id="value_file"><?php echo $resultado['url_img_logo']; ?></span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img" required="">
                            </label>
                        </label>
                        <label>Informações da Empresa:
                            <input class="information" type="text" value="<?php echo $resultado['text_info']; ?>" name="info" placeholder='Pular linha: "<br>"' required="">
                        </label>
                        <label>Email:
                            <input class="email" type="text" value="<?php echo $resultado['email']; ?>" name="email" placeholder="@gmail.com" required="">
                        </label>
                        <label>Telefone:
                            <input class="telefone" type="text" value="<?php echo $resultado['telefone']; ?>" name="telefone" placeholder="(xx) xxxx-xxxx" required="">
                        </label>
                        <button type="submit" style="background-color: #0c0;" class="enviar">Atualizar</button>
                    </form>
                <?php } ?>
            </div>
        </div>
        <div class="card" style="width: 99%; margin-top: 20px; padding: 40px 5px;">
            <h4>Rodapé Cadastrado</h4>
            <hr>
            <div class="text">
                <table>
                    <tbody>
                        <tr>
                            <th>Id</th>
                            <th>Imagem</th>
                            <th>Titulo</th>
                            <th>Texto botão</th>
                            <th>Link Botão</th>
                            <th>Editar</th>
                            <th>Excluir</th>
                        </tr>
                        <?php $busca_slide = 'SELECT * FROM rodape';
                        $query_slide = $connect->query($busca_slide);
                        $count = 1;
                        while ($result = $query_slide->fetch_assoc()) {
                            $id = $result['id'];
                            $img = $result['url_img_logo'];
                            $text_info = $result['text_info'];
                            $telefone = $result['telefone'];
                            $email = $result['email'];
                            echo "
                                    <tr>
                                        <td>$id</td>
                                        <td><img src='../assets/img/$img' style='max-width: 120px;'></td>
                                        <td>$text_info</td>
                                        <td>$telefone</td>
                                        <td>$email</td>
                                        <td><a href='rodape.php?id=$id'><img src='../assets/img/edit.svg' style='max-width: 20px;'></a></td>
                                        <td>
                                            <form action='assets/functions/delete.php' id='form$id'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='exclui' name='acao' style='display: none;'>
                                                <input type='text' value='rodape' name='tabela' style='display: none;'>
                                                <input type='text' value='$img' name='img' style='display: none;'>
                                                <button type='button' onclick='confirmar($id)' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/lixo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
    if (isset($_GET["sucesso"])) {
        echo "<script>alert('Sucesso!!!')</script>";
    } else if (isset($_GET["erro"])) {
        echo "<script>alert('Alguma coisa deu errado, tente novamente mais tarde.')</script>";
    }
    ?>
</body>

</html>