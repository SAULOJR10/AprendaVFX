<?php
if (!isset($_SESSION)) {
    session_start();
     if(isset($_SESSION['UsuarioId'])){
        header("location: index.php");
     }
}

if(isset($_GET["sair"])){
    session_destroy();
    header("location: login.php");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- ----------Importa head---------- -->
    <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
    <div class="menu-top">
        <center><a href="#"><img loading="lazy" class="logo" src="../assets/img/logo-navbar.webp" alt=""></a></center>
    </div>
    <!-- End menu superior -->

    <div class="content-controle">
        <div class="card">
            <div class="text">
                <form action="assets/functions/validar_user.php" method="post">
                    <legend>Dados de Login</legend>
                    <label>Usuário
                        <input type="text" name="usuario" class="user" maxlength="25" required=""/>
                    </label>
                    <label>Senha
                        <input type="password" name="senha" class="senha" required=""/>
                    </label>
                    <button type="submit" class="enviar">Enviar</button>
                </form>
            </div>
        </div>
    </div>
    <?php
    if (isset($_GET["sucesso"])) {
        echo "<script>alert('Sucesso!!!')</script>";
    } else if (isset($_GET["erro"])) {
        echo "<script>alert('Usuário inválido!!!')</script>";
    }
    ?>
</body>

</html>