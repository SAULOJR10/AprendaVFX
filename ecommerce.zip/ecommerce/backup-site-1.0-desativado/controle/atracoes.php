<?php
require_once "../assets/bib/conexao.php";

if (!isset($_SESSION)) session_start();

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID'])) {
    // Destrói a sessão por segurança
    session_destroy();
    // Redireciona o visitante de volta pro login
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- ----------Importa head---------- -->
    <?php require_once "head.php" ?>
    <!-- -------------------------------- -->
</head>

<body>
    <!-- Importa menus lateral e superior -->
    <?php if ($_SESSION["UsuarioNivel"] == "cl") {
        require_once "menus.php";
    } else {
        require_once "menus_adm.php";
    }
    ?>

    <div class="content-controle">
        <div class="card">
            <div class="text">
                <h4>Atrações</h4>
                <p class="informacao">o que estou editando?</p>
                <?php if (!isset($_GET['id'])) { ?>
                    <form action="assets/functions/insert.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="atracao" style="display: none;" required="">
                        <label class="metade">Imagem:
                            <label class="label_file"><span id="value_file">Arquivo</span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img" required="">
                            </label>
                        </label>
                        <label class="metade">Ordem:
                            <input class="order" type="text" name="order" placeholder="Exibição" required="">
                        </label>
                        <label>Titulo:
                            <input class="title" type="text" name="title" placeholder="Nome da atração" required="">
                        </label>
                        <label class="metade">Hr. aberto:
                            <input class="time" type="text" name="hr_abert" placeholder="00:00" required="">
                        </label>
                        <label class="metade">Hr. fechado:
                            <input class="time" type="text" name="hr_fecha" placeholder="00:00" required="">
                        </label>
                        <label class="metade">Categoria:
                            <input class="categoria" type="text" name="cat" placeholder="Lazer" required="">
                        </label>
                        <label class="metade">Parque:
                            <select name="parque" required="">
                                <option value="">Selecione</option>
                                <option value="1">Clube Privé</option>
                                <option value="2">Water Park</option>
                                <option value="3">Náutico</option>
                            </select>
                        </label>
                        <label>Descrição:
                            <input class="description" type="text" name="desc" placeholder="Pense na atração" required="">
                        </label>
                        <button type="submit" class="enviar">Enviar</button>
                    </form>
                <?php } else if ($_GET['id'] != '') {
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM atracoes WHERE id = $id LIMIT 1";
                    $query_slide = $connect->query($sql);
                    $resultado = $query_slide->fetch_assoc();
                ?>
                    <form action="assets/functions/update.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="acao" value="atracao" style="display: none;" required="">
                        <input type="text" name="id" value="<?php echo $_GET['id']; ?>" style="display: none;" required="">
                        <label class="metade">Imagem:
                            <input style="display: none;" value="<?php echo $resultado['url_img']; ?>" type="text" name="img_text" required="">
                            <label class="label_file"><span id="value_file"><?php echo $resultado['url_img']; ?></span>
                                <input class="clip" id="img" onchange="mudar_valor()" type="file" name="img" required="">
                            </label>
                        </label>
                        <label class="metade">Ordem:
                            <input class="order" type="text" value="<?php echo $resultado['ordem']; ?>" name="order" placeholder="Ordem de exibição" required="">
                        </label>
                        <label>Titulo:
                            <input class="title" type="text" value="<?php echo $resultado['nome']; ?>" name="title" placeholder="Nome da atração" required="">
                        </label>
                        <label class="metade">Hrs abertura:
                            <input class="time" type="text" value="<?php echo $resultado['hr_abert']; ?>" name="hr_abert" placeholder="00:00" required="">
                        </label>
                        <label class="metade">Hrs fechamento:
                            <input class="time" type="text" value="<?php echo $resultado['hr_fecha']; ?>" name="hr_fecha" placeholder="00:00" required="">
                        </label>
                        <label class="metade">Categoria:
                            <input class="categoria" type="text" value="<?php echo $resultado['categoria']; ?>" name="cat" placeholder="Aventura, Familiar" required="">
                        </label>
                        <label class="metade">Parque:
                            <select name="parque" required="">
                                <option value="">Selecione</option>
                                <option value="1" <?php if ($resultado['id_parque'] == 1) { ?> selected <?php } ?>>Clube Privé</option>
                                <option value="2" <?php if ($resultado['id_parque'] == 2) { ?> selected <?php } ?>>Water Park</option>
                                <option value="3" <?php if ($resultado['id_parque'] == 3) { ?> selected <?php } ?>>Náutico</option>
                            </select>
                        </label>
                        <label>Descrição:
                            <input class="description" type="text" value="<?php echo $resultado['descricao']; ?>" name="desc" placeholder="Pense na atração" required="">
                        </label>
                        <button type="submit" style="background-color: #0c0;" class="enviar">Atualizar</button>
                    </form>
                <?php } ?>
            </div>
        </div>
        <div class="card" style="width: 99%; margin-top: 20px; padding: 40px 5px;">
            <h4>Atrações Cadastradas</h4>
            <hr>
            <div class="text">
                <table>
                    <tbody>
                        <tr>
                            <th>Id</th>
                            <th>Imagem</th>
                            <th>Nome</th>
                            <th>Hr aberto</th>
                            <th>Hr fechado</th>
                            <th>Ordem</th>
                            <th>Editar</th>
                            <th>Ativar / Desativar</th>
                            <th>Excluir</th>
                        </tr>
                        <?php $busca_slide = 'SELECT * FROM atracoes ORDER BY id_parque, ordem';
                        $query_slide = $connect->query($busca_slide);
                        $count = 1;
                        while ($result = $query_slide->fetch_assoc()) {
                            $id = $result['id'];
                            $img = $result['url_img'];
                            $nome = $result['nome'];
                            $hr_abert = $result['hr_abert'];
                            $hr_fecha = $result['hr_fecha'];
                            $ordem = $result['ordem'];
                            $status = $result['status'];
                            $tabela = "<tr>
                                        <td>$id</td>
                                        <td><img src='../assets/img/$img' style='max-width: 120px;'></td>
                                        <td>$nome</td>
                                        <td>$hr_abert</td>
                                        <td>$hr_fecha</td>
                                        <td>$ordem</td>
                                        <td><a href='atracoes.php?id=$id'><img src='../assets/img/edit.svg' style='max-width: 20px;'></a></td>";
                            if ($status == 1) {
                                $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='desativa' name='acao' style='display: none;'>
                                                <input type='text' value='atracoes' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/ativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                            } else {
                                $tabela .= "<td>
                                            <form action='assets/functions/update.php'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='ativa' name='acao' style='display: none;'>
                                                <input type='text' value='atracoes' name='tabela' style='display: none;'>
                                                <button type='submit' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/desativo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>";
                            }
                            $tabela .= "<td>
                                            <form action='assets/functions/delete.php' id='form$id'  method='post' enctype='multipart/form-data'>
                                                <input type='text' value='$id' name='id' style='display: none;'>
                                                <input type='text' value='exclui' name='acao' style='display: none;'>
                                                <input type='text' value='atracoes' name='tabela' style='display: none;'>
                                                <button type='button' onclick='confirmar($id)' style='background-color: transparent; border: none; width: 100%;'>
                                                    <img src='../assets/img/lixo.svg' style='max-width: 20px;'>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>";
                            echo $tabela;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
    if (isset($_GET["sucesso"])) {
        echo "<script>alert('Sucesso!!!')</script>";
    } else if (isset($_GET["erro"])) {
        echo "<script>alert('Alguma coisa deu errado, tente novamente mais tarde.')</script>";
    }
    ?>
</body>

</html>