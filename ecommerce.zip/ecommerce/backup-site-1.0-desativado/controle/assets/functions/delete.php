<?php
require_once "../../../assets/bib/conexao.php";
$retorno = explode('?', $_SERVER['HTTP_REFERER'])[0];

session_start();

if (isset($_POST['acao'])) {
    switch ($_POST['acao']) {
        case 'exclui':
            delete();
            break;
        case 'exclui_login':
            delete_login();
            break;
    }
} else {
    header("location: ../../index.php");
    exit;
}

function delete()
{
    global $connect;
    $id = $_POST["id"];
    $tabela = $_POST["tabela"];
    $img = $_POST["img"];

    $sql = "DELETE FROM `$tabela` WHERE id=$id";

    unlink('../../../assets/img/' . $img);

    if ($connect->query($sql)) {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?sucesso=');
    } else {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?erro=');
    }
}

function delete_login()
{
    global $connect;
    $id = $_POST["id"];

    $sql = "DELETE FROM `login` WHERE id=$id";
    $sql2 = "DELETE FROM `usuario` WHERE id_login=$id";

    if ($connect->query($sql) && $connect->query($sql2)) {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?sucesso=');
    } else {
        header("location: " . $_SERVER['HTTP_REFERER'] . '?erro=');
    }
}