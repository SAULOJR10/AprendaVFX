<?php
require_once "../../../assets/bib/conexao.php";
$retorno = explode('?', $_SERVER['HTTP_REFERER'])[0];

session_start();

if (isset($_POST['acao'])) {
    switch ($_POST['acao']) {
        case 'slide_mobile':
            update_slide_mobile();
            break;
        case 'slide_pc':
            update_slide_pc();
            break;
        case 'atracao':
            update_atracao();
            break;
        case 'promocao':
            update_promocao();
            break;
        case 'pergunta':
            update_pergunta();
            break;
        case 'rodape':
            update_rodape();
            break;
        case 'usuario':
            update_login();
            break;
        case 'ativa':
            ativa();
            break;
        case 'desativa':
            desativa();
            break;
    }
} else {
    header("location: ../../index.php");
    exit;
}

function update_slide_pc()
{
    global $retorno;
    global $connect;
    $img = "";
    if ($_FILES["img"]["name"] != "") {
        unlink('../../../assets/img/' . $_POST['img_text']);
        $img = move_file($_FILES["img"]);
    } else {
        $img = $_POST["img_text"];
    }
    $id = $_POST["id"];
    $desc = $_POST["desc"];
    $order = $_POST["order"];
    $status = $_POST["status"];

    $sql = "UPDATE slide_home_pc SET url_img = '$img', descricao = '$desc', ordem = '$order', status = '$status' WHERE id = $id";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function update_slide_mobile()
{
    global $retorno;
    global $connect;
    $img = "";
    if ($_FILES["img"]["name"] != "") {
        unlink('../../../assets/img/' . $_POST['img_text']);
        $img = move_file($_FILES["img"]);
    } else {
        $img = $_POST["img_text"];
    }
    $id = $_POST["id"];
    $desc = $_POST["desc"];
    $order = $_POST["order"];
    $status = $_POST["status"];

    $sql = "UPDATE slide_home_mobile SET url_img = '$img', descricao = '$desc', ordem = '$order', status = '$status' WHERE id = $id";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function update_atracao()
{
    global $retorno;
    global $connect;
    $img = "";
    if ($_FILES["img"]["name"] != "") {
        unlink('../../../assets/img/' . $_POST['img_text']);
        $img = move_file($_FILES["img"]);
    } else {
        $img = $_POST["img_text"];
    }
    $id = $_POST["id"];
    $title = $_POST["title"];
    $desc = $_POST["desc"];
    $hr_abert = $_POST["hr_abert"];
    $hr_fecha = $_POST["hr_fecha"];
    $cat = $_POST["cat"];
    $order = $_POST["order"];
    $id_parque = $_POST["parque"];

    $sql = "UPDATE `atracoes` SET `id_parque` = '$id_parque', `url_img` = '$img', `nome` = '$title', `descricao` = '$desc', `categoria` = '$cat', `hr_abert` = '$hr_abert', `hr_fecha` = '$hr_fecha', `ordem` = '$order', `status` = 1 WHERE id = $id";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function update_promocao()
{
    global $retorno;
    global $connect;
    $img = "";
    if ($_FILES["img"]["name"] != "") {
        unlink('../../../assets/img/' . $_POST['img_text']);
        $img = move_file($_FILES["img"]);
    } else {
        $img = $_POST["img_text"];
    }
    $id = $_POST["id"];
    $title = $_POST["title"];
    $botao = $_POST["botao"];
    $link = $_POST["link"];

    $sql = "UPDATE `promocao` SET `url_img` = '$img', `titulo` = '$title', `link` = '$link', `text_button` = '$botao', `status` = 1 WHERE id = $id";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function update_rodape()
{
    global $retorno;
    global $connect;
    $img = "";
    if ($_FILES["img"]["name"] != "") {
        unlink('../../../assets/img/' . $_POST['img_text']);
        $img = move_file($_FILES["img"]);
    } else {
        $img = $_POST["img_text"];
    }
    $id = $_POST["id"];
    $info = $_POST["info"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];

    $sql = "UPDATE `rodape` SET `url_img_logo` = '$img', `text_info` = '$info', `telefone` = '$telefone', `email` = '$email' WHERE id = $id";
    echo $sql;
    exit;
    if ($connect->query($sql) && $img != 'erro') {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function update_pergunta()
{
    global $retorno;
    global $connect;
    $id = $_POST["id"];
    $pergunta = $_POST["pergunta"];
    $resposta = $_POST["resposta"];
    $tipo = $_POST["tipo"];

    $sql = "UPDATE `faq` SET `pergunta` = '$pergunta', `resposta` = '$resposta', `tipo_faq` = '$tipo', `status` = 1 WHERE id = $id";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function update_login(){
    global $retorno;
    global $connect;
    $id = $_POST["id"];
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $cep = $_POST["cep"];
    $telefone = $_POST["telefone"];
    $nascimento = $_POST["nascimento"];
    $email = $_POST["email"];
    $login = $_POST["login"];
    $nivel = $_POST["nivel"];

    $sql_usuario = "UPDATE `usuario` SET `nome`='$nome',`cpf`='$cpf',`cep`='$cep',`telefone`='$telefone',`email`='$email',`data_nascimento`='$nascimento' WHERE id_login = $id";
    $sql_login = "UPDATE `login` SET `login`='$login',`nivel`='$nivel' WHERE id = $id";

    if ($connect->query($sql_usuario) && $connect->query($sql_login)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function move_file($arquivo)
{
    global $retorno;
    //TESTA SE JÁ EXISTE ARQUIVO COM O MESMO NOME
    $files = glob('./**/*/' . $arquivo['name']);
    if (empty($files) || $files != false) {
        //MOVE FILE
        $ext = strtolower(substr($arquivo['name'], -4)); //Pegando extensão do arquivo
        if ($ext = "webp") {
            $ext = ".webp";
        }
        $img = date("Y.m.d-H.i.s") . $ext; //Definindo um novo nome para o arquivo
        $dir = '../../../assets/img/'; //Diretório para uploads 
        if (!move_uploaded_file($_FILES['img']['tmp_name'], $dir . $img)) { //Fazer upload do arquivo
            header("location: " . $retorno . '?erro=');
            exit;
        } //se não fizer upload, retorna erro

        return $img;
    } else {
        return $arquivo['name'];
    }
}

function ativa()
{
    global $retorno;
    global $connect;
    $id = $_POST["id"];
    $tabela = $_POST["tabela"];

    $sql = "UPDATE `$tabela` SET `status` = 1 WHERE id = $id";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}

function desativa()
{
    global $retorno;
    global $connect;
    $id = $_POST["id"];
    $tabela = $_POST["tabela"];

    $sql = "UPDATE `$tabela` SET `status` = 0 WHERE id = $id";
    if ($connect->query($sql)) {
        header("location: " . $retorno . '?sucesso=');
    } else {
        header("location: " . $retorno . '?erro=');
    }
}
