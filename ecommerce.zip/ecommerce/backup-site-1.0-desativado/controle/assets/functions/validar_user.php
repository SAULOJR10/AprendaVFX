<?php
require_once "../../../assets/bib/conexao.php";

  // Verifica se houve POST e se o usuário ou a senha é(são) vazio(s)
  if (!empty($_POST) AND (empty($_POST['usuario']) OR empty($_POST['senha']))) {
      header("Location: index.php"); exit;
  }else{
    $login = $_POST['usuario'];
    $senha = md5($_POST['senha']);
  }

  // Validação do usuário/senha digitados
  $sql = "SELECT `id`, `login`, `senha`, `nivel` FROM `login` WHERE login = '$login' and senha = '$senha' and status = 1";
  $result = $connect->query($sql);
  if (mysqli_num_rows($result) != 1) {
      // Mensagem de erro quando os dados são inválidos e/ou o usuário não foi encontrado
      header("Location: ../../login.php?erro="); exit;
  } else {
      // Salva os dados encontados na variável $resultado
      $resultado = mysqli_fetch_assoc($result);

      // Se a sessão não existir, inicia uma
      if (!isset($_SESSION)) session_start();

      // Salva os dados encontrados na sessão
      $_SESSION['UsuarioID'] = $resultado['id'];
      $_SESSION['UsuarioNivel'] = $resultado['nivel'];

      // Redireciona o visitante
      header("Location: ../../index.php"); exit;
  }