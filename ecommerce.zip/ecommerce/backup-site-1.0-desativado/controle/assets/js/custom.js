function confirmar(form) {
    var x;
    var r = confirm("Se você excluir esse item essa ação não poderá ser desfeita! Tem certeza que deseja excluir?");
    if (r == true) {
        document.getElementById('form' + form).submit();
    }
}