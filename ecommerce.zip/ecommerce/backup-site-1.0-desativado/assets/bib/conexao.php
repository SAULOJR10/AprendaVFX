<?php
$servername = "localhost";
$database = "site-temp";
$username = "282372d8bdc1";
$password = "e8c02ddff79566aa";
// Create connection
$connect = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
?>